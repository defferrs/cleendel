import { execSync } from 'child_process';

console.log('🚀 Memulai setup bot otomatis...\n');

try {
  console.log('🔧 Step 1/2: Mendaftarkan slash commands...');
  try {
    execSync('npm run register', { stdio: 'inherit' });
    console.log('✅ Slash commands berhasil didaftarkan!\n');
  } catch (error) {
    console.log('⚠️  Commands sudah terdaftar atau error diabaikan\n');
  }

  console.log('🤖 Step 2/2: Memulai Discord bot...\n');
  console.log('━'.repeat(50));
  
  execSync('node index.js', { stdio: 'inherit' });
  
} catch (error) {
  console.error('❌ Error saat menjalankan bot:', error.message);
  process.exit(1);
}
