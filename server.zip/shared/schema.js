import { pgTable, text, serial, integer, timestamp, boolean, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  discordId: varchar("discord_id", { length: 255 }).notNull().unique(),
  username: varchar("username", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  bio: text("bio"),
  whatsOnYourMind: text("whats_on_your_mind"),
  avatarUrl: text("avatar_url"),
  bannerUrl: text("banner_url"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const twickPosts = pgTable("twick_posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  imageUrl: text("image_url"),
  videoUrl: text("video_url"),
  serverId: varchar("server_id", { length: 255 }).notNull(),
  messageId: varchar("message_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const twickLikes = pgTable("twick_likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => twickPosts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const twickReplies = pgTable("twick_replies", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => twickPosts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const twickReposts = pgTable("twick_reposts", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").references(() => twickPosts.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  serverId: varchar("server_id", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const marketplaceListings = pgTable("marketplace_listings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  price: varchar("price", { length: 100 }).notNull(),
  imageUrl: text("image_url"),
  serverId: varchar("server_id", { length: 255 }).notNull(),
  messageId: varchar("message_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const marketplaceLikes = pgTable("marketplace_likes", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").references(() => marketplaceListings.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  isLike: boolean("is_like").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const marketplaceComments = pgTable("marketplace_comments", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").references(() => marketplaceListings.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const partyRooms = pgTable("party_rooms", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").references(() => users.id).notNull(),
  channelId: varchar("channel_id", { length: 255 }).notNull().unique(),
  serverId: varchar("server_id", { length: 255 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  isLocked: boolean("is_locked").default(false).notNull(),
  userLimit: integer("user_limit"),
  bitrate: integer("bitrate").default(64000),
  region: varchar("region", { length: 100 }),
  loungeType: text("lounge_type").default("private"),
  trustedUsers: text("trusted_users"),
  blockedUsers: text("blocked_users"),
  waitingRoomChannelId: varchar("waiting_room_channel_id", { length: 255 }),
  threadId: varchar("thread_id", { length: 255 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const serverSettings = pgTable("server_settings", {
  id: serial("id").primaryKey(),
  serverId: varchar("server_id", { length: 255 }).notNull().unique(),
  twickChannelId: varchar("twick_channel_id", { length: 255 }),
  marketplaceChannelId: varchar("marketplace_channel_id", { length: 255 }),
  loungeCategoryId: varchar("lounge_category_id", { length: 255 }),
  loungeControlChannelId: varchar("lounge_control_channel_id", { length: 255 }),
  loungeCreateChannelId: varchar("lounge_create_channel_id", { length: 255 }),
  gameCategoryId: text("game_category_id"),
  gameControlChannelId: text("game_control_channel_id"),
  gameCreateChannelId: text("game_create_channel_id"),
  chillCategoryId: text("chill_category_id"),
  chillControlChannelId: text("chill_control_channel_id"),
  chillCreateChannelId: text("chill_create_channel_id"),
  chillMusicChannelId: text("chill_music_channel_id"),
  customEmojis: text("custom_emojis"),
  privateLoungeNames: text("private_lounge_names"),
  gameLoungeNames: text("game_lounge_names"),
  chillLoungeNames: text("chill_lounge_names"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  twickPosts: many(twickPosts),
  twickLikes: many(twickLikes),
  twickReplies: many(twickReplies),
  twickReposts: many(twickReposts),
  marketplaceListings: many(marketplaceListings),
  marketplaceLikes: many(marketplaceLikes),
  marketplaceComments: many(marketplaceComments),
  partyRooms: many(partyRooms),
}));

export const profilesRelations = relations(profiles, ({ one }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
}));

export const twickPostsRelations = relations(twickPosts, ({ one, many }) => ({
  user: one(users, {
    fields: [twickPosts.userId],
    references: [users.id],
  }),
  likes: many(twickLikes),
  replies: many(twickReplies),
  reposts: many(twickReposts),
}));

export const marketplaceListingsRelations = relations(marketplaceListings, ({ one, many }) => ({
  user: one(users, {
    fields: [marketplaceListings.userId],
    references: [users.id],
  }),
  likes: many(marketplaceLikes),
  comments: many(marketplaceComments),
}));

export const partyRoomsRelations = relations(partyRooms, ({ one }) => ({
  owner: one(users, {
    fields: [partyRooms.ownerId],
    references: [users.id],
  }),
}));