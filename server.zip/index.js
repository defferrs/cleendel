import { Client, GatewayIntentBits, Partials, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionFlagsBits, ChannelType, ModalBuilder, TextInputBuilder, TextInputStyle, StringSelectMenuBuilder } from 'discord.js';
import dotenv from 'dotenv';
import { db } from './server/db.js';
import { initDatabase } from './server/init-db.js';
import { users, profiles, twickPosts, twickLikes, twickReplies, twickReposts, marketplaceListings, marketplaceLikes, marketplaceComments, partyRooms, serverSettings } from './shared/schema.js';
import { eq, and, desc, sql } from 'drizzle-orm';

dotenv.config();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

async function getOrCreateUser(discordId, username) {
  let [user] = await db.select().from(users).where(eq(users.discordId, discordId));

  if (!user) {
    [user] = await db.insert(users).values({ discordId, username }).returning();
    await db.insert(profiles).values({ userId: user.id });
  }

  return user;
}

client.once('ready', () => {
  console.log(`✅ Bot siap! Logged in sebagai ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isCommand()) {
      const { commandName } = interaction;

      if (commandName === 'partyroom') {
        await handlePartyRoomCommand(interaction);
      } else if (commandName === 'gamelounge') {
        await handleGameLoungeCommand(interaction);
      } else if (commandName === 'chilllounge') {
        await handleChillLoungeCommand(interaction);
      } else if (commandName === 'twick') {
        await handleTwickCommand(interaction);
      } else if (commandName === 'profile') {
        await handleProfileCommand(interaction);
      } else if (commandName === 'marketplace') {
        await handleMarketplaceCommand(interaction);
      } else if (commandName === 'setup') {
        await handleSetupCommand(interaction);
      } else if (commandName === 'customizelounge') {
        await handleCustomizeLoungeCommand(interaction);
      } else if (commandName === 'duplicatelounge') {
        await handleDuplicateLoungeCommand(interaction);
      } else if (commandName === 'deletelounge') {
        await handleDeleteLoungeCommand(interaction);
      } else if (commandName === 'help') {
        await handleHelpCommand(interaction);
      } else if (commandName === 'customrpc') {
        await handleCustomRPCCommand(interaction);
      }
    } else if (interaction.isButton()) {
      const [action, ...params] = interaction.customId.split('_');

      if (action === 'partyroom') {
        await handlePartyRoomButton(interaction, params);
      } else if (action === 'lounge') {
        await handleLoungeButton(interaction, params);
      } else if (action === 'gamelounge') {
        await handleGameLoungeButton(interaction, params);
      } else if (action === 'chilllounge') {
        await handleChillLoungeButton(interaction, params);
      } else if (action === 'twick') {
        await handleTwickButton(interaction, params);
      } else if (action === 'marketplace') {
        await handleMarketplaceButton(interaction, params);
      }
    } else if (interaction.isModalSubmit()) {
      const [action] = interaction.customId.split('_');

      if (action === 'lounge') {
        await handleLoungeModal(interaction);
      } else if (action === 'gamelounge') {
        await handleGameLoungeModal(interaction);
      } else if (action === 'chilllounge') {
        await handleChillLoungeModal(interaction);
      } else if (action === 'twick') {
        await handleTwickModal(interaction);
      } else if (action === 'profile') {
        await handleProfileModal(interaction);
      } else if (action === 'marketplace') {
        await handleMarketplaceModal(interaction);
      } else if (action === 'comment') {
        await handleCommentModal(interaction);
      } else if (action === 'reply') {
        await handleReplyModal(interaction);
      }
    } else if (interaction.isStringSelectMenu()) {
      const [action] = interaction.customId.split('_');

      if (action === 'setup') {
        await handleSetupSelect(interaction);
      } else if (interaction.customId === 'twick_select_post') {
        await handleTwickPostSelect(interaction);
      }
    }
  } catch (error) {
    console.error('Error handling interaction:', error);
    const reply = { content: 'Terjadi kesalahan saat memproses permintaan Anda.', ephemeral: true };

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(reply);
    } else {
      await interaction.reply(reply);
    }
  }
});

async function createPrivateLounge(interaction, settings, customNames = null) {
  const categoryName = customNames?.categoryName || '🔊═════ PRIVATE LOUNGE';
  const controlName = customNames?.controlChannel || '🛠️┆settings-private';
  const createName = customNames?.createChannel || '🔊┆Create Private';

  const category = await interaction.guild.channels.create({
    name: categoryName,
    type: ChannelType.GuildCategory,
  });

  const controlChannel = await interaction.guild.channels.create({
    name: controlName,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
        deny: [PermissionFlagsBits.SendMessages],
      },
    ],
  });

  const createChannel = await interaction.guild.channels.create({
    name: createName,
    type: ChannelType.GuildVoice,
    parent: category.id,
    userLimit: 1,
  });

  const customEmojis = settings?.customEmojis ? JSON.parse(settings.customEmojis) : {};
  const defaultEmojis = ['📝', '⚠️', '🔒', '⏳', '💬', '✅', '❌', '📩', '🥾', '🌐', '🚫', '🔓', '👑', '📤', '🗑️'];
  const emojis = customEmojis.private ? [...customEmojis.private, ...defaultEmojis.slice(customEmojis.private.length)] : defaultEmojis;

  const embed = new EmbedBuilder()
    .setColor('#5865F2')
    .setTitle('Private Lounge')
    .setDescription('Menu ini digunakan untuk membuat Private Lounge.\n\n**Cara Menggunakannya:**\nSilahkan masuk ke 🔊┆Create Private lalu pilih game melalui menu dibawah ini sesuai yang anda inginkan.\n\nJika ada masalah dengan Private Lounge, Silahkan hubungi **STAFF** yang tersedia.')
    .setFooter({ text: `${interaction.guild.name} - ${new Date().getFullYear()}deffano_hansen` });

  const row1 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('lounge_name')
        .setLabel(`${emojis[0]} NAME`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_limit')
        .setLabel(`${emojis[1]} LIMIT`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_privacy')
        .setLabel(`${emojis[2]} PRIVACY`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_waiting')
        .setLabel(`${emojis[3]} WAITING R.`)
        .setStyle(ButtonStyle.Secondary)
    );

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('lounge_trust')
        .setLabel(`${emojis[5]} TRUST`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_untrust')
        .setLabel(`${emojis[6]} UNTRUST`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_invite')
        .setLabel(`${emojis[7]} INVITE`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_kick')
        .setLabel(`${emojis[8]} KICK`)
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('lounge_region')
        .setLabel(`${emojis[9]} REGION`)
        .setStyle(ButtonStyle.Secondary)
    );

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('lounge_block')
        .setLabel(`${emojis[10]} BLOCK`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_unblock')
        .setLabel(`${emojis[11]} UNBLOCK`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('lounge_claim')
        .setLabel(`${emojis[12]} CLAIM`)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('lounge_transfer')
        .setLabel(`${emojis[13]} TRANSFER`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('lounge_delete')
        .setLabel(`${emojis[14]} DELETE`)
        .setStyle(ButtonStyle.Danger)
    );

  await controlChannel.send({ embeds: [embed], components: [row1, row2, row3] });

  if (!settings) {
    await db.insert(serverSettings).values({
      serverId: interaction.guild.id,
      loungeCategoryId: category.id,
      loungeControlChannelId: controlChannel.id,
      loungeCreateChannelId: createChannel.id,
    });
  } else {
    await db.update(serverSettings)
      .set({
        loungeCategoryId: category.id,
        loungeControlChannelId: controlChannel.id,
        loungeCreateChannelId: createChannel.id,
        updatedAt: new Date(),
      })
      .where(eq(serverSettings.serverId, interaction.guild.id));
  }

  return { category, controlChannel, createChannel };
}

async function createGameLounge(interaction, settings, customNames = null) {
  const categoryName = customNames?.categoryName || '🎮═════ GAME LOUNGE';
  const controlName = customNames?.controlChannel || '🛠️┆settings-game';
  const createName = customNames?.createChannel || '🎮┆Create Game Room';

  const category = await interaction.guild.channels.create({
    name: categoryName,
    type: ChannelType.GuildCategory,
  });

  const controlChannel = await interaction.guild.channels.create({
    name: controlName,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
        deny: [PermissionFlagsBits.SendMessages],
      },
    ],
  });

  const createChannel = await interaction.guild.channels.create({
    name: createName,
    type: ChannelType.GuildVoice,
    parent: category.id,
    userLimit: 1,
  });

  const customEmojis = settings?.customEmojis ? JSON.parse(settings.customEmojis) : {};
  const defaultEmojis = ['📝', '⚠️', '🔒', '⏳', '💬', '✅', '❌', '📩', '🥾', '🌐', '🚫', '🔓', '👑', '📤', '🗑️'];
  const emojis = customEmojis.game ? [...customEmojis.game, ...defaultEmojis.slice(customEmojis.game.length)] : defaultEmojis;

  const embed = new EmbedBuilder()
    .setColor('#E74C3C')
    .setTitle('🎮 Game Lounge')
    .setDescription('Menu ini digunakan untuk membuat Game Lounge untuk bermain game bersama.\n\n**Cara Menggunakannya:**\nSilahkan masuk ke 🎮┆Create Game Room lalu atur room sesuai kebutuhan.\n\n**Limit Default:** 5 orang (Max 5 orang)')
    .setFooter({ text: `${interaction.guild.name} - ${new Date().getFullYear()}deffano_hansen` });

  const row1 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('gamelounge_name')
        .setLabel(`${emojis[0]} NAME`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_limit')
        .setLabel(`${emojis[1]} LIMIT`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_privacy')
        .setLabel(`${emojis[2]} PRIVACY`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_waiting')
        .setLabel(`${emojis[3]} WAITING R.`)
        .setStyle(ButtonStyle.Secondary)
    );

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('gamelounge_trust')
        .setLabel(`${emojis[5]} TRUST`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_untrust')
        .setLabel(`${emojis[6]} UNTRUST`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_invite')
        .setLabel(`${emojis[7]} INVITE`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_kick')
        .setLabel(`${emojis[8]} KICK`)
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('gamelounge_region')
        .setLabel(`${emojis[9]} REGION`)
        .setStyle(ButtonStyle.Secondary)
    );

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('gamelounge_block')
        .setLabel(`${emojis[10]} BLOCK`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_unblock')
        .setLabel(`${emojis[11]} UNBLOCK`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('gamelounge_claim')
        .setLabel(`${emojis[12]} CLAIM`)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('gamelounge_transfer')
        .setLabel(`${emojis[13]} TRANSFER`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('gamelounge_delete')
        .setLabel(`${emojis[14]} DELETE`)
        .setStyle(ButtonStyle.Danger)
    );

  await controlChannel.send({ embeds: [embed], components: [row1, row2, row3] });

  if (!settings) {
    await db.insert(serverSettings).values({
      serverId: interaction.guild.id,
      gameCategoryId: category.id,
      gameControlChannelId: controlChannel.id,
      gameCreateChannelId: createChannel.id,
    });
  } else {
    await db.update(serverSettings)
      .set({
        gameCategoryId: category.id,
        gameControlChannelId: controlChannel.id,
        gameCreateChannelId: createChannel.id,
        updatedAt: new Date(),
      })
      .where(eq(serverSettings.serverId, interaction.guild.id));
  }

  return { category, controlChannel, createChannel };
}

async function createChillLounge(interaction, settings, customNames = null) {
  const categoryName = customNames?.categoryName || '🎧═════ CHILL LOUNGE';
  const controlName = customNames?.controlChannel || '🛠️┆settings-chill';
  const createName = customNames?.createChannel || '🎧┆Create Chill Room';

  const category = await interaction.guild.channels.create({
    name: categoryName,
    type: ChannelType.GuildCategory,
  });

  const controlChannel = await interaction.guild.channels.create({
    name: controlName,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: [
      {
        id: interaction.guild.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
        deny: [PermissionFlagsBits.SendMessages],
      },
    ],
  });

  const musicChannel = await interaction.guild.channels.create({
    name: '🎵┆music-commands',
    type: ChannelType.GuildText,
    parent: category.id,
  });

  const createChannel = await interaction.guild.channels.create({
    name: createName,
    type: ChannelType.GuildVoice,
    parent: category.id,
    userLimit: 1,
  });

  const customEmojis = settings?.customEmojis ? JSON.parse(settings.customEmojis) : {};
  const defaultEmojis = ['📝', '⚠️', '🔒', '⏳', '💬', '✅', '❌', '📩', '🥾', '🌐', '🚫', '🔓', '👑', '📤', '🗑️'];
  const emojis = customEmojis.chill ? [...customEmojis.chill, ...defaultEmojis.slice(customEmojis.chill.length)] : defaultEmojis;

  const embed = new EmbedBuilder()
    .setColor('#3498DB')
    .setTitle('🎧 Chill Lounge')
    .setDescription('Menu ini digunakan untuk membuat Chill Lounge untuk bersantai dan mendengarkan musik.\n\n**Cara Menggunakannya:**\nSilahkan masuk ke 🎧┆Create Chill Room lalu atur room sesuai kebutuhan.\n\n**Channel Music:** Gunakan <#' + musicChannel.id + '> untuk command music bot.')
    .setFooter({ text: `${interaction.guild.name} - ${new Date().getFullYear()}deffano_hansen` });

  const row1 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('chilllounge_name')
        .setLabel(`${emojis[0]} NAME`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_limit')
        .setLabel(`${emojis[1]} LIMIT`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_privacy')
        .setLabel(`${emojis[2]} PRIVACY`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_waiting')
        .setLabel(`${emojis[3]} WAITING R.`)
        .setStyle(ButtonStyle.Secondary)
    );

  const row2 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('chilllounge_trust')
        .setLabel(`${emojis[5]} TRUST`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_untrust')
        .setLabel(`${emojis[6]} UNTRUST`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_invite')
        .setLabel(`${emojis[7]} INVITE`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_kick')
        .setLabel(`${emojis[8]} KICK`)
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('chilllounge_region')
        .setLabel(`${emojis[9]} REGION`)
        .setStyle(ButtonStyle.Secondary)
    );

  const row3 = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('chilllounge_block')
        .setLabel(`${emojis[10]} BLOCK`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_unblock')
        .setLabel(`${emojis[11]} UNBLOCK`)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('chilllounge_claim')
        .setLabel(`${emojis[12]} CLAIM`)
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('chilllounge_transfer')
        .setLabel(`${emojis[13]} TRANSFER`)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('chilllounge_delete')
        .setLabel(`${emojis[14]} DELETE`)
        .setStyle(ButtonStyle.Danger)
    );

  await controlChannel.send({ embeds: [embed], components: [row1, row2, row3] });

  if (!settings) {
    await db.insert(serverSettings).values({
      serverId: interaction.guild.id,
      chillCategoryId: category.id,
      chillControlChannelId: controlChannel.id,
      chillCreateChannelId: createChannel.id,
      chillMusicChannelId: musicChannel.id,
    });
  } else {
    await db.update(serverSettings)
      .set({
        chillCategoryId: category.id,
        chillControlChannelId: controlChannel.id,
        chillCreateChannelId: createChannel.id,
        chillMusicChannelId: musicChannel.id,
        updatedAt: new Date(),
      })
      .where(eq(serverSettings.serverId, interaction.guild.id));
  }

  return { category, controlChannel, createChannel, musicChannel };
}

async function handlePartyRoomCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

  if (settings?.loungeCategoryId) {
    await interaction.reply({ content: '❌ Private Lounge sudah di-setup di server ini.', ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#5865F2')
    .setTitle('🔊 Setup Private Lounge')
    .setDescription('Pilih cara setup Private Lounge:\n\n**Otomatis**: Bot akan membuat lounge dengan pengaturan default\n**Custom**: Anda dapat mengkustomisasi nama-nama channel terlebih dahulu');

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('partyroom_auto')
        .setLabel('🤖 Otomatis')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('partyroom_custom')
        .setLabel('✨ Custom')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function handleGameLoungeCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

  if (settings?.gameCategoryId) {
    await interaction.reply({ content: '❌ Game Lounge sudah di-setup di server ini.', ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#E74C3C')
    .setTitle('🎮 Setup Game Lounge')
    .setDescription('Pilih cara setup Game Lounge:\n\n**Otomatis**: Bot akan membuat lounge dengan pengaturan default\n**Custom**: Anda dapat mengkustomisasi nama-nama channel terlebih dahulu');

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('gamelounge_auto')
        .setLabel('🤖 Otomatis')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('gamelounge_custom')
        .setLabel('✨ Custom')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function handleChillLoungeCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

  if (settings?.chillCategoryId) {
    await interaction.reply({ content: '❌ Chill Lounge sudah di-setup di server ini.', ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#3498DB')
    .setTitle('🎧 Setup Chill Lounge')
    .setDescription('Pilih cara setup Chill Lounge:\n\n**Otomatis**: Bot akan membuat lounge dengan pengaturan default\n**Custom**: Anda dapat mengkustomisasi nama-nama channel terlebih dahulu');

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('chilllounge_auto')
        .setLabel('🤖 Otomatis')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('chilllounge_custom')
        .setLabel('✨ Custom')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function handleGameLoungeButton(interaction, params) {
  const action = params[0];
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (action === 'auto') {
    await interaction.deferReply({ ephemeral: true });

    const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

    try {
      let customNames = null;
      try {
        customNames = settings?.gameLoungeNames ? JSON.parse(settings.gameLoungeNames) : null;
      } catch (e) {
        console.error('Failed to parse gameLoungeNames:', e);
      }

      const { category, controlChannel, createChannel } = await createGameLounge(interaction, settings, customNames);

      await interaction.editReply({ content: `✅ Game Lounge berhasil di-setup!\n\n📁 Category: <#${category.id}>\n🛠️ Control: <#${controlChannel.id}>\n🎮 Create: <#${createChannel.id}>` });
    } catch (error) {
      console.error('Error setting up game lounge:', error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat setup Game Lounge.' });
    }
    return;
  } else if (action === 'custom') {
    const modal = new ModalBuilder()
      .setCustomId('gamelounge_custom_modal')
      .setTitle('Customize Game Lounge');

    const categoryInput = new TextInputBuilder()
      .setCustomId('category_name')
      .setLabel('Nama Category')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🎮═════ GAME LOUNGE')
      .setValue('🎮═════ GAME LOUNGE');

    const controlInput = new TextInputBuilder()
      .setCustomId('control_name')
      .setLabel('Nama Control Channel')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🛠️┆settings-game')
      .setValue('🛠️┆settings-game');

    const createInput = new TextInputBuilder()
      .setCustomId('create_name')
      .setLabel('Nama Create Channel')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🎮┆Create Game Room')
      .setValue('🎮┆Create Game Room');

    modal.addComponents(
      new ActionRowBuilder().addComponents(categoryInput),
      new ActionRowBuilder().addComponents(controlInput),
      new ActionRowBuilder().addComponents(createInput)
    );

    await interaction.showModal(modal);
    return;
  }

  if (!interaction.member.voice?.channelId) {
    await interaction.reply({ content: '❌ Kamu harus berada di voice channel untuk menggunakan fitur ini.', ephemeral: true });
    return;
  }

  const [room] = await db.select().from(partyRooms).where(
    and(
      eq(partyRooms.channelId, interaction.member.voice.channelId),
      eq(partyRooms.serverId, interaction.guild.id),
      eq(partyRooms.loungeType, 'game')
    )
  );

  if (!room) {
    await interaction.reply({ content: '❌ Kamu tidak berada di game lounge.', ephemeral: true });
    return;
  }

  if (action === 'name') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa rename channel.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_name_modal_${room.id}`)
      .setTitle('Rename Channel');

    const nameInput = new TextInputBuilder()
      .setCustomId('channel_name')
      .setLabel('Nama Channel Baru')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(100);

    modal.addComponents(new ActionRowBuilder().addComponents(nameInput));
    await interaction.showModal(modal);
  } else if (action === 'limit') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah limit.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_limit_modal_${room.id}`)
      .setTitle('Set User Limit (Max 5)');

    const limitInput = new TextInputBuilder()
      .setCustomId('limit_value')
      .setLabel('User Limit (1-5)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('5');

    modal.addComponents(new ActionRowBuilder().addComponents(limitInput));
    await interaction.showModal(modal);
  } else if (action === 'privacy') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah privacy.', ephemeral: true });
      return;
    }

    const newLockState = !room.isLocked;
    await db.update(partyRooms).set({ isLocked: newLockState }).where(eq(partyRooms.id, room.id));

    const channel = await interaction.guild.channels.fetch(room.channelId);
    await channel.permissionOverwrites.edit(interaction.guild.id, {
      Connect: !newLockState
    });

    await interaction.reply({ content: `✅ Room berhasil ${newLockState ? 'di-lock 🔒' : 'di-unlock 🔓'}`, ephemeral: true });
  } else if (action === 'waiting') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengelola waiting room.', ephemeral: true });
      return;
    }

    if (room.waitingRoomChannelId) {
      const waitingChannel = await interaction.guild.channels.fetch(room.waitingRoomChannelId).catch(() => null);
      if (waitingChannel) {
        await waitingChannel.delete();
        await db.update(partyRooms).set({ waitingRoomChannelId: null }).where(eq(partyRooms.id, room.id));
        await interaction.reply({ content: '✅ Waiting room berhasil dihapus.', ephemeral: true });
      } else {
        await db.update(partyRooms).set({ waitingRoomChannelId: null }).where(eq(partyRooms.id, room.id));
        await interaction.reply({ content: '⚠️ Waiting room sudah tidak ada, database diperbarui.', ephemeral: true });
      }
    } else {
      const channel = await interaction.guild.channels.fetch(room.channelId);
      const waitingChannel = await interaction.guild.channels.create({
        name: `⏳ ${room.name} - Waiting`,
        type: ChannelType.GuildVoice,
        parent: channel.parentId,
      });

      await db.update(partyRooms).set({ waitingRoomChannelId: waitingChannel.id }).where(eq(partyRooms.id, room.id));
      await interaction.reply({ content: `✅ Waiting room berhasil dibuat: <#${waitingChannel.id}>`, ephemeral: true });
    }
  } else if (action === 'thread') {
    // Thread functionality removed
  } else if (action === 'trust') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menambah trusted users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_trust_modal_${room.id}`)
      .setTitle('Add Trusted User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan ditambahkan')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'untrust') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menghapus trusted users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_untrust_modal_${room.id}`)
      .setTitle('Remove Trusted User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan dihapus')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'invite') {
    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_invite_modal_${room.id}`)
      .setTitle('Invite User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan diundang')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'kick') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa kick user.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_kick_modal_${room.id}`)
      .setTitle('Kick User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan di-kick')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'region') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah region.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_region_modal_${room.id}`)
      .setTitle('Set Region');

    const regionInput = new TextInputBuilder()
      .setCustomId('region_value')
      .setLabel('Region (brazil/hongkong/india/japan/dll)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('singapore');

    modal.addComponents(new ActionRowBuilder().addComponents(regionInput));
    await interaction.showModal(modal);
  } else if (action === 'block') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa memblokir users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_block_modal_${room.id}`)
      .setTitle('Block User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan diblokir')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'unblock') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa membuka blokir users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_unblock_modal_${room.id}`)
      .setTitle('Unblock User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan di-unblock')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'claim') {
    const channel = await interaction.guild.channels.fetch(room.channelId);
    const [ownerUser] = await db.select().from(users).where(eq(users.id, room.ownerId));
    const owner = ownerUser ? await interaction.guild.members.fetch(ownerUser.discordId).catch(() => null) : null;

    if (owner && channel.members.has(owner.id)) {
      await interaction.reply({ content: '❌ Owner masih ada di channel.', ephemeral: true });
      return;
    }

    await db.update(partyRooms).set({ ownerId: user.id }).where(eq(partyRooms.id, room.id));
    await interaction.reply({ content: '✅ Kamu sekarang owner channel ini!', ephemeral: true });
  } else if (action === 'transfer') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa transfer ownership.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_transfer_modal_${room.id}`)
      .setTitle('Transfer Ownership');

    const userInput = new TextInputBuilder()
      .setCustomId('new_owner_id')
      .setLabel('User ID owner baru')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'delete') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menghapus lounge.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`gamelounge_delete_modal_${room.id}`)
      .setTitle('Delete Lounge');

    const confirmInput = new TextInputBuilder()
      .setCustomId('confirm')
      .setLabel('Ketik DELETE untuk konfirmasi')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(confirmInput));
    await interaction.showModal(modal);
  }
}

async function handleChillLoungeButton(interaction, params) {
  const action = params[0];
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (action === 'auto') {
    await interaction.deferReply({ ephemeral: true });

    const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

    try {
      let customNames = null;
      try {
        customNames = settings?.chillLoungeNames ? JSON.parse(settings.chillLoungeNames) : null;
      } catch (e) {
        console.error('Failed to parse chillLoungeNames:', e);
      }

      const { category, controlChannel, createChannel, musicChannel } = await createChillLounge(interaction, settings, customNames);

      await interaction.editReply({ content: `✅ Chill Lounge berhasil di-setup!\n\n📁 Category: <#${category.id}>\n🛠️ Control: <#${controlChannel.id}>\n🎧 Create: <#${createChannel.id}>\n🎵 Music: <#${musicChannel.id}>` });
    } catch (error) {
      console.error('Error setting up chill lounge:', error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat setup Chill Lounge.' });
    }
    return;
  } else if (action === 'custom') {
    const modal = new ModalBuilder()
      .setCustomId('chilllounge_custom_modal')
      .setTitle('Customize Chill Lounge');

    const categoryInput = new TextInputBuilder()
      .setCustomId('category_name')
      .setLabel('Nama Category')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🎧═════ CHILL LOUNGE')
      .setValue('🎧═════ CHILL LOUNGE');

    const controlInput = new TextInputBuilder()
      .setCustomId('control_name')
      .setLabel('Nama Control Channel')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🛠️┆settings-chill')
      .setValue('🛠️┆settings-chill');

    const createInput = new TextInputBuilder()
      .setCustomId('create_name')
      .setLabel('Nama Create Channel')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🎧┆Create Chill Room')
      .setValue('🎧┆Create Chill Room');

    modal.addComponents(
      new ActionRowBuilder().addComponents(categoryInput),
      new ActionRowBuilder().addComponents(controlInput),
      new ActionRowBuilder().addComponents(createInput)
    );

    await interaction.showModal(modal);
    return;
  }

  if (!interaction.member.voice?.channelId) {
    await interaction.reply({ content: '❌ Kamu harus berada di voice channel untuk menggunakan fitur ini.', ephemeral: true });
    return;
  }

  const [room] = await db.select().from(partyRooms).where(
    and(
      eq(partyRooms.channelId, interaction.member.voice.channelId),
      eq(partyRooms.serverId, interaction.guild.id),
      eq(partyRooms.loungeType, 'chill')
    )
  );

  if (!room) {
    await interaction.reply({ content: '❌ Kamu tidak berada di chill lounge.', ephemeral: true });
    return;
  }

  if (action === 'name') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa rename channel.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_name_modal_${room.id}`)
      .setTitle('Rename Channel');

    const nameInput = new TextInputBuilder()
      .setCustomId('channel_name')
      .setLabel('Nama Channel Baru')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(100);

    modal.addComponents(new ActionRowBuilder().addComponents(nameInput));
    await interaction.showModal(modal);
  } else if (action === 'limit') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah limit.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_limit_modal_${room.id}`)
      .setTitle('Set User Limit');

    const limitInput = new TextInputBuilder()
      .setCustomId('limit_value')
      .setLabel('Pilih: 2, 4, 5, 10, 15, 20')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('5');

    modal.addComponents(new ActionRowBuilder().addComponents(limitInput));
    await interaction.showModal(modal);
  } else if (action === 'privacy') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah privacy.', ephemeral: true });
      return;
    }

    const newLockState = !room.isLocked;
    await db.update(partyRooms).set({ isLocked: newLockState }).where(eq(partyRooms.id, room.id));

    const channel = await interaction.guild.channels.fetch(room.channelId);
    await channel.permissionOverwrites.edit(interaction.guild.id, {
      Connect: !newLockState
    });

    await interaction.reply({ content: `✅ Room berhasil ${newLockState ? 'di-lock 🔒' : 'di-unlock 🔓'}`, ephemeral: true });
  } else if (action === 'waiting') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengelola waiting room.', ephemeral: true });
      return;
    }

    if (room.waitingRoomChannelId) {
      const waitingChannel = await interaction.guild.channels.fetch(room.waitingRoomChannelId).catch(() => null);
      if (waitingChannel) {
        await waitingChannel.delete();
        await db.update(partyRooms).set({ waitingRoomChannelId: null }).where(eq(partyRooms.id, room.id));
        await interaction.reply({ content: '✅ Waiting room berhasil dihapus.', ephemeral: true });
      } else {
        await db.update(partyRooms).set({ waitingRoomChannelId: null }).where(eq(partyRooms.id, room.id));
        await interaction.reply({ content: '⚠️ Waiting room sudah tidak ada, database diperbarui.', ephemeral: true });
      }
    } else {
      const channel = await interaction.guild.channels.fetch(room.channelId);
      const waitingChannel = await interaction.guild.channels.create({
        name: `⏳ ${room.name} - Waiting`,
        type: ChannelType.GuildVoice,
        parent: channel.parentId,
      });

      await db.update(partyRooms).set({ waitingRoomChannelId: waitingChannel.id }).where(eq(partyRooms.id, room.id));
      await interaction.reply({ content: `✅ Waiting room berhasil dibuat: <#${waitingChannel.id}>`, ephemeral: true });
    }
  } else if (action === 'thread') {
    // Thread functionality removed
  } else if (action === 'trust') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menambah trusted users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_trust_modal_${room.id}`)
      .setTitle('Add Trusted User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan ditambahkan')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'untrust') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menghapus trusted users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_untrust_modal_${room.id}`)
      .setTitle('Remove Trusted User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan dihapus')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'invite') {
    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_invite_modal_${room.id}`)
      .setTitle('Invite User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan diundang')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'kick') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa kick user.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_kick_modal_${room.id}`)
      .setTitle('Kick User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan di-kick')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'region') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah region.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_region_modal_${room.id}`)
      .setTitle('Set Region');

    const regionInput = new TextInputBuilder()
      .setCustomId('region_value')
      .setLabel('Region (brazil/hongkong/india/japan/dll)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('singapore');

    modal.addComponents(new ActionRowBuilder().addComponents(regionInput));
    await interaction.showModal(modal);
  } else if (action === 'block') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa memblokir users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_block_modal_${room.id}`)
      .setTitle('Block User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan diblokir')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'unblock') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa membuka blokir users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_unblock_modal_${room.id}`)
      .setTitle('Unblock User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan di-unblock')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'claim') {
    const channel = await interaction.guild.channels.fetch(room.channelId);
    const [ownerUser] = await db.select().from(users).where(eq(users.id, room.ownerId));
    const owner = ownerUser ? await interaction.guild.members.fetch(ownerUser.discordId).catch(() => null) : null;

    if (owner && channel.members.has(owner.id)) {
      await interaction.reply({ content: '❌ Owner masih ada di channel.', ephemeral: true });
      return;
    }

    await db.update(partyRooms).set({ ownerId: user.id }).where(eq(partyRooms.id, room.id));
    await interaction.reply({ content: '✅ Kamu sekarang owner channel ini!', ephemeral: true });
  } else if (action === 'transfer') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa transfer ownership.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_transfer_modal_${room.id}`)
      .setTitle('Transfer Ownership');

    const userInput = new TextInputBuilder()
      .setCustomId('new_owner_id')
      .setLabel('User ID owner baru')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'delete') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menghapus lounge.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`chilllounge_delete_modal_${room.id}`)
      .setTitle('Delete Lounge');

    const confirmInput = new TextInputBuilder()
      .setCustomId('confirm')
      .setLabel('Ketik DELETE untuk konfirmasi')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(confirmInput));
    await interaction.showModal(modal);
  }
}

async function handleGameLoungeModal(interaction) {
  const [, type, , roomId] = interaction.customId.split('_');
  const room = await db.select().from(partyRooms).where(eq(partyRooms.id, parseInt(roomId)));

  if (!room || room.length === 0) {
    await interaction.reply({ content: '❌ Room tidak ditemukan.', ephemeral: true });
    return;
  }

  const roomData = room[0];
  const channel = await interaction.guild.channels.fetch(roomData.channelId);

  if (type === 'name') {
    const newName = interaction.fields.getTextInputValue('channel_name');

    await channel.setName(newName);
    await db.update(partyRooms).set({ name: newName }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Channel berhasil di-rename menjadi "${newName}"`, ephemeral: true });
  } else if (type === 'limit') {
    const limit = parseInt(interaction.fields.getTextInputValue('limit_value'));

    if (limit < 1 || limit > 5) {
      await interaction.reply({ content: '❌ Limit harus antara 1-5 untuk Game Lounge.', ephemeral: true });
      return;
    }

    await channel.setUserLimit(limit);
    await db.update(partyRooms).set({ userLimit: limit }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ User limit diubah menjadi ${limit}`, ephemeral: true });
  } else if (type === 'region') {
    const region = interaction.fields.getTextInputValue('region_value');
    const validRegions = ['brazil', 'hongkong', 'india', 'japan', 'rotterdam', 'singapore', 'south-korea', 'southafrica', 'sydney', 'us-central', 'us-east', 'us-south', 'us-west'];

    if (!validRegions.includes(region.toLowerCase())) {
      await interaction.reply({ content: `❌ Region tidak valid. Pilih: ${validRegions.join(', ')}`, ephemeral: true });
      return;
    }

    await channel.setRTCRegion(region);
    await db.update(partyRooms).set({ region }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Region diubah menjadi ${region}`, ephemeral: true });
  } else if (type === 'trust') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const trustedUsers = roomData.trustedUsers ? JSON.parse(roomData.trustedUsers) : [];
    if (trustedUsers.includes(userId)) {
      await interaction.reply({ content: '❌ User sudah ada di trusted list.', ephemeral: true });
      return;
    }

    trustedUsers.push(userId);
    await db.update(partyRooms).set({ trustedUsers: JSON.stringify(trustedUsers) }).where(eq(partyRooms.id, roomData.id));

    if (roomData.isLocked) {
      await channel.permissionOverwrites.edit(userId, { Connect: true });
    }

    await interaction.reply({ content: `✅ ${member.user.username} ditambahkan ke trusted users.`, ephemeral: true });
  } else if (type === 'untrust') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const trustedUsers = roomData.trustedUsers ? JSON.parse(roomData.trustedUsers) : [];
    const index = trustedUsers.indexOf(userId);

    if (index === -1) {
      await interaction.reply({ content: '❌ User tidak ada di trusted list.', ephemeral: true });
      return;
    }

    trustedUsers.splice(index, 1);
    await db.update(partyRooms).set({ trustedUsers: JSON.stringify(trustedUsers) }).where(eq(partyRooms.id, roomData.id));

    if (roomData.isLocked) {
      await channel.permissionOverwrites.delete(userId);
    }

    await interaction.reply({ content: `✅ ${member.user.username} dihapus dari trusted users.`, ephemeral: true });
  } else if (type === 'invite') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const inviter = await interaction.guild.members.fetch(interaction.user.id);
    await member.send(`📩 ${inviter.user.username} mengundang kamu ke voice channel: <#${roomData.channelId}> di server ${interaction.guild.name}!`).catch(() => null);

    await interaction.reply({ content: `✅ Undangan telah dikirim ke ${member.user.username}.`, ephemeral: true });
  } else if (type === 'block') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const blockedUsers = roomData.blockedUsers ? JSON.parse(roomData.blockedUsers) : [];
    if (blockedUsers.includes(userId)) {
      await interaction.reply({ content: '❌ User sudah diblokir.', ephemeral: true });
      return;
    }

    blockedUsers.push(userId);
    await db.update(partyRooms).set({ blockedUsers: JSON.stringify(blockedUsers) }).where(eq(partyRooms.id, roomData.id));

    await channel.permissionOverwrites.edit(userId, { Connect: false });

    if (member.voice.channelId === roomData.channelId) {
      await member.voice.disconnect();
    }

    await interaction.reply({ content: `✅ ${member.user.username} berhasil diblokir.`, ephemeral: true });
  } else if (type === 'unblock') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const blockedUsers = roomData.blockedUsers ? JSON.parse(roomData.blockedUsers) : [];
    const index = blockedUsers.indexOf(userId);

    if (index === -1) {
      await interaction.reply({ content: '❌ User tidak diblokir.', ephemeral: true });
      return;
    }

    blockedUsers.splice(index, 1);
    await db.update(partyRooms).set({ blockedUsers: JSON.stringify(blockedUsers) }).where(eq(partyRooms.id, roomData.id));

    await channel.permissionOverwrites.delete(userId);

    await interaction.reply({ content: `✅ ${member.user.username} berhasil di-unblock.`, ephemeral: true });
  } else if (type === 'kick') {
    const userId = interaction.fields.getTextInputValue('user_id');

    const member = await interaction.guild.members.fetch(userId).catch(() => null);
    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    if (member.voice.channelId !== roomData.channelId) {
      await interaction.reply({ content: '❌ User tidak ada di channel ini.', ephemeral: true });
      return;
    }

    await member.voice.disconnect();
    await interaction.reply({ content: `✅ ${member.user.username} berhasil di-kick dari channel.`, ephemeral: true });
  } else if (type === 'transfer') {
    const newOwnerId = interaction.fields.getTextInputValue('new_owner_id');

    const newOwner = await interaction.guild.members.fetch(newOwnerId).catch(() => null);
    if (!newOwner) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    if (newOwner.voice.channelId !== roomData.channelId) {
      await interaction.reply({ content: '❌ User harus ada di channel untuk menjadi owner.', ephemeral: true });
      return;
    }

    const user = await getOrCreateUser(newOwnerId, newOwner.user.username);
    await db.update(partyRooms).set({ ownerId: user.id }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Ownership berhasil ditransfer ke ${newOwner.user.username}`, ephemeral: true });
  } else if (type === 'delete') {
    const confirm = interaction.fields.getTextInputValue('confirm');

    if (confirm !== 'DELETE') {
      await interaction.reply({ content: '❌ Konfirmasi salah. Ketik DELETE untuk menghapus.', ephemeral: true });
      return;
    }

    if (roomData.waitingRoomChannelId) {
      const waitingChannel = await interaction.guild.channels.fetch(roomData.waitingRoomChannelId).catch(() => null);
      if (waitingChannel) await waitingChannel.delete();
    }

    // Thread deletion removed

    await channel.delete();
    await db.delete(partyRooms).where(eq(partyRooms.id, roomData.id));

    await interaction.reply({ content: '✅ Lounge berhasil dihapus.', ephemeral: true });
  }
}

async function handleChillLoungeModal(interaction) {
  const [, type, , roomId] = interaction.customId.split('_');
  const room = await db.select().from(partyRooms).where(eq(partyRooms.id, parseInt(roomId)));

  if (!room || room.length === 0) {
    await interaction.reply({ content: '❌ Room tidak ditemukan.', ephemeral: true });
    return;
  }

  const roomData = room[0];
  const channel = await interaction.guild.channels.fetch(roomData.channelId);

  if (type === 'name') {
    const newName = interaction.fields.getTextInputValue('channel_name');

    await channel.setName(newName);
    await db.update(partyRooms).set({ name: newName }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Channel berhasil di-rename menjadi "${newName}"`, ephemeral: true });
  } else if (type === 'limit') {
    const limit = parseInt(interaction.fields.getTextInputValue('limit_value'));
    const validLimits = [2, 4, 5, 10, 15, 20];

    if (!validLimits.includes(limit)) {
      await interaction.reply({ content: '❌ Limit harus salah satu dari: 2, 4, 5, 10, 15, 20', ephemeral: true });
      return;
    }

    await channel.setUserLimit(limit);
    await db.update(partyRooms).set({ userLimit: limit }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ User limit diubah menjadi ${limit}`, ephemeral: true });
  } else if (type === 'region') {
    const region = interaction.fields.getTextInputValue('region_value');
    const validRegions = ['brazil', 'hongkong', 'india', 'japan', 'rotterdam', 'singapore', 'south-korea', 'southafrica', 'sydney', 'us-central', 'us-east', 'us-south', 'us-west'];

    if (!validRegions.includes(region.toLowerCase())) {
      await interaction.reply({ content: `❌ Region tidak valid. Pilih: ${validRegions.join(', ')}`, ephemeral: true });
      return;
    }

    await channel.setRTCRegion(region);
    await db.update(partyRooms).set({ region }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Region diubah menjadi ${region}`, ephemeral: true });
  } else if (type === 'trust') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const trustedUsers = roomData.trustedUsers ? JSON.parse(roomData.trustedUsers) : [];
    if (trustedUsers.includes(userId)) {
      await interaction.reply({ content: '❌ User sudah ada di trusted list.', ephemeral: true });
      return;
    }

    trustedUsers.push(userId);
    await db.update(partyRooms).set({ trustedUsers: JSON.stringify(trustedUsers) }).where(eq(partyRooms.id, roomData.id));

    if (roomData.isLocked) {
      await channel.permissionOverwrites.edit(userId, { Connect: true });
    }

    await interaction.reply({ content: `✅ ${member.user.username} ditambahkan ke trusted users.`, ephemeral: true });
  } else if (type === 'untrust') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const trustedUsers = roomData.trustedUsers ? JSON.parse(roomData.trustedUsers) : [];
    const index = trustedUsers.indexOf(userId);

    if (index === -1) {
      await interaction.reply({ content: '❌ User tidak ada di trusted list.', ephemeral: true });
      return;
    }

    trustedUsers.splice(index, 1);
    await db.update(partyRooms).set({ trustedUsers: JSON.stringify(trustedUsers) }).where(eq(partyRooms.id, roomData.id));

    if (roomData.isLocked) {
      await channel.permissionOverwrites.delete(userId);
    }

    await interaction.reply({ content: `✅ ${member.user.username} dihapus dari trusted users.`, ephemeral: true });
  } else if (type === 'invite') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const inviter = await interaction.guild.members.fetch(interaction.user.id);
    await member.send(`📩 ${inviter.user.username} mengundang kamu ke voice channel: <#${roomData.channelId}> di server ${interaction.guild.name}!`).catch(() => null);

    await interaction.reply({ content: `✅ Undangan telah dikirim ke ${member.user.username}.`, ephemeral: true });
  } else if (type === 'block') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const blockedUsers = roomData.blockedUsers ? JSON.parse(roomData.blockedUsers) : [];
    if (blockedUsers.includes(userId)) {
      await interaction.reply({ content: '❌ User sudah diblokir.', ephemeral: true });
      return;
    }

    blockedUsers.push(userId);
    await db.update(partyRooms).set({ blockedUsers: JSON.stringify(blockedUsers) }).where(eq(partyRooms.id, roomData.id));

    await channel.permissionOverwrites.edit(userId, { Connect: false });

    if (member.voice.channelId === roomData.channelId) {
      await member.voice.disconnect();
    }

    await interaction.reply({ content: `✅ ${member.user.username} berhasil diblokir.`, ephemeral: true });
  } else if (type === 'unblock') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const blockedUsers = roomData.blockedUsers ? JSON.parse(roomData.blockedUsers) : [];
    const index = blockedUsers.indexOf(userId);

    if (index === -1) {
      await interaction.reply({ content: '❌ User tidak diblokir.', ephemeral: true });
      return;
    }

    blockedUsers.splice(index, 1);
    await db.update(partyRooms).set({ blockedUsers: JSON.stringify(blockedUsers) }).where(eq(partyRooms.id, roomData.id));

    await channel.permissionOverwrites.delete(userId);

    await interaction.reply({ content: `✅ ${member.user.username} berhasil di-unblock.`, ephemeral: true });
  } else if (type === 'kick') {
    const userId = interaction.fields.getTextInputValue('user_id');

    const member = await interaction.guild.members.fetch(userId).catch(() => null);
    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    if (member.voice.channelId !== roomData.channelId) {
      await interaction.reply({ content: '❌ User tidak ada di channel ini.', ephemeral: true });
      return;
    }

    await member.voice.disconnect();
    await interaction.reply({ content: `✅ ${member.user.username} berhasil di-kick dari channel.`, ephemeral: true });
  } else if (type === 'transfer') {
    const newOwnerId = interaction.fields.getTextInputValue('new_owner_id');

    const newOwner = await interaction.guild.members.fetch(newOwnerId).catch(() => null);
    if (!newOwner) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    if (newOwner.voice.channelId !== roomData.channelId) {
      await interaction.reply({ content: '❌ User harus ada di channel untuk menjadi owner.', ephemeral: true });
      return;
    }

    const user = await getOrCreateUser(newOwnerId, newOwner.user.username);
    await db.update(partyRooms).set({ ownerId: user.id }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Ownership berhasil ditransfer ke ${newOwner.user.username}`, ephemeral: true });
  } else if (type === 'delete') {
    const confirm = interaction.fields.getTextInputValue('confirm');

    if (confirm !== 'DELETE') {
      await interaction.reply({ content: '❌ Konfirmasi salah. Ketik DELETE untuk menghapus.', ephemeral: true });
      return;
    }

    if (roomData.waitingRoomChannelId) {
      const waitingChannel = await interaction.guild.channels.fetch(roomData.waitingRoomChannelId).catch(() => null);
      if (waitingChannel) await waitingChannel.delete();
    }

    // Thread deletion removed

    await channel.delete();
    await db.delete(partyRooms).where(eq(partyRooms.id, roomData.id));

    await interaction.reply({ content: '✅ Lounge berhasil dihapus.', ephemeral: true });
  }
}

async function handleLoungeButton(interaction, params) {
  const action = params[0];
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (!interaction.member.voice?.channelId) {
    await interaction.reply({ content: '❌ Kamu harus berada di voice channel untuk menggunakan fitur ini.', ephemeral: true });
    return;
  }

  const [room] = await db.select().from(partyRooms).where(
    and(
      eq(partyRooms.channelId, interaction.member.voice.channelId),
      eq(partyRooms.serverId, interaction.guild.id)
    )
  );

  if (!room) {
    await interaction.reply({ content: '❌ Kamu tidak berada di private lounge.', ephemeral: true });
    return;
  }

  if (action === 'name') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa rename channel.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_name_modal_${room.id}`)
      .setTitle('Rename Channel');

    const nameInput = new TextInputBuilder()
      .setCustomId('channel_name')
      .setLabel('Nama Channel Baru')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(100);

    modal.addComponents(new ActionRowBuilder().addComponents(nameInput));
    await interaction.showModal(modal);
  } else if (action === 'limit') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah limit.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_limit_modal_${room.id}`)
      .setTitle('Set User Limit');

    const limitInput = new TextInputBuilder()
      .setCustomId('limit_value')
      .setLabel('User Limit (0 = unlimited)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('0');

    modal.addComponents(new ActionRowBuilder().addComponents(limitInput));
    await interaction.showModal(modal);
  } else if (action === 'privacy') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah privacy.', ephemeral: true });
      return;
    }

    const newLockState = !room.isLocked;
    await db.update(partyRooms).set({ isLocked: newLockState }).where(eq(partyRooms.id, room.id));

    const channel = await interaction.guild.channels.fetch(room.channelId);
    await channel.permissionOverwrites.edit(interaction.guild.id, {
      Connect: !newLockState
    });

    await interaction.reply({ content: `✅ Room berhasil ${newLockState ? 'di-lock 🔒' : 'di-unlock 🔓'}`, ephemeral: true });
  } else if (action === 'waiting') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengelola waiting room.', ephemeral: true });
      return;
    }

    if (room.waitingRoomChannelId) {
      const waitingChannel = await interaction.guild.channels.fetch(room.waitingRoomChannelId).catch(() => null);
      if (waitingChannel) {
        await waitingChannel.delete();
        await db.update(partyRooms).set({ waitingRoomChannelId: null }).where(eq(partyRooms.id, room.id));
        await interaction.reply({ content: '✅ Waiting room berhasil dihapus.', ephemeral: true });
      } else {
        await db.update(partyRooms).set({ waitingRoomChannelId: null }).where(eq(partyRooms.id, room.id));
        await interaction.reply({ content: '⚠️ Waiting room sudah tidak ada, database diperbarui.', ephemeral: true });
      }
    } else {
      const channel = await interaction.guild.channels.fetch(room.channelId);
      const waitingChannel = await interaction.guild.channels.create({
        name: `⏳ ${room.name} - Waiting`,
        type: ChannelType.GuildVoice,
        parent: channel.parentId,
      });

      await db.update(partyRooms).set({ waitingRoomChannelId: waitingChannel.id }).where(eq(partyRooms.id, room.id));
      await interaction.reply({ content: `✅ Waiting room berhasil dibuat: <#${waitingChannel.id}>`, ephemeral: true });
    }
  } else if (action === 'thread') {
    // Thread functionality removed
  } else if (action === 'trust') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menambah trusted users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_trust_modal_${room.id}`)
      .setTitle('Add Trusted User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan ditambahkan')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'untrust') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menghapus trusted users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_untrust_modal_${room.id}`)
      .setTitle('Remove Trusted User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan dihapus')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'invite') {
    const modal = new ModalBuilder()
      .setCustomId(`lounge_invite_modal_${room.id}`)
      .setTitle('Invite User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan diundang')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'kick') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa kick user.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_kick_modal_${room.id}`)
      .setTitle('Kick User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan di-kick')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'region') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa mengubah region.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_region_modal_${room.id}`)
      .setTitle('Set Region');

    const regionInput = new TextInputBuilder()
      .setCustomId('region_value')
      .setLabel('Region (auto/singapore/japan/hongkong)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('auto');

    modal.addComponents(new ActionRowBuilder().addComponents(regionInput));
    await interaction.showModal(modal);
  } else if (action === 'block') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa memblokir users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_block_modal_${room.id}`)
      .setTitle('Block User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan diblokir')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'unblock') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa membuka blokir users.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_unblock_modal_${room.id}`)
      .setTitle('Unblock User');

    const userInput = new TextInputBuilder()
      .setCustomId('user_id')
      .setLabel('User ID yang akan di-unblock')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'claim') {
    const channel = await interaction.guild.channels.fetch(room.channelId);
    const [ownerUser] = await db.select().from(users).where(eq(users.id, room.ownerId));
    const owner = ownerUser ? await interaction.guild.members.fetch(ownerUser.discordId).catch(() => null) : null;

    if (owner && channel.members.has(owner.id)) {
      await interaction.reply({ content: '❌ Owner masih ada di channel.', ephemeral: true });
      return;
    }

    await db.update(partyRooms).set({ ownerId: user.id }).where(eq(partyRooms.id, room.id));
    await interaction.reply({ content: '✅ Kamu sekarang owner channel ini!', ephemeral: true });
  } else if (action === 'transfer') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa transfer ownership.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_transfer_modal_${room.id}`)
      .setTitle('Transfer Ownership');

    const userInput = new TextInputBuilder()
      .setCustomId('new_owner_id')
      .setLabel('User ID owner baru')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(userInput));
    await interaction.showModal(modal);
  } else if (action === 'delete') {
    if (room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Hanya owner yang bisa menghapus lounge.', ephemeral: true });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`lounge_delete_modal_${room.id}`)
      .setTitle('Delete Lounge');

    const confirmInput = new TextInputBuilder()
      .setCustomId('confirm')
      .setLabel('Ketik DELETE untuk konfirmasi')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(confirmInput));
    await interaction.showModal(modal);
  }
}

async function handleLoungeModal(interaction) {
  const [, type, , roomId] = interaction.customId.split('_');
  const room = await db.select().from(partyRooms).where(eq(partyRooms.id, parseInt(roomId)));

  if (!room || room.length === 0) {
    await interaction.reply({ content: '❌ Room tidak ditemukan.', ephemeral: true });
    return;
  }

  const roomData = room[0];
  const channel = await interaction.guild.channels.fetch(roomData.channelId);

  if (type === 'name') {
    const newName = interaction.fields.getTextInputValue('channel_name');

    await channel.setName(newName);
    await db.update(partyRooms).set({ name: newName }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Channel berhasil di-rename menjadi "${newName}"`, ephemeral: true });
  } else if (type === 'limit') {
    const limit = parseInt(interaction.fields.getTextInputValue('limit_value'));

    if (limit < 0 || limit > 99) {
      await interaction.reply({ content: '❌ Limit harus antara 0-99.', ephemeral: true });
      return;
    }

    await channel.setUserLimit(limit);
    await db.update(partyRooms).set({ userLimit: limit === 0 ? null : limit }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ User limit diubah menjadi ${limit === 0 ? 'unlimited' : limit}`, ephemeral: true });
  } else if (type === 'region') {
    const region = interaction.fields.getTextInputValue('region_value');
    const validRegions = ['auto', 'singapore', 'japan', 'hongkong', 'sydney', 'us-east', 'us-west', 'europe'];

    if (!validRegions.includes(region.toLowerCase())) {
      await interaction.reply({ content: `❌ Region tidak valid. Pilih: ${validRegions.join(', ')}`, ephemeral: true });
      return;
    }

    await channel.setRTCRegion(region === 'auto' ? null : region);
    await db.update(partyRooms).set({ region: region === 'auto' ? null : region }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Region diubah menjadi ${region}`, ephemeral: true });
  } else if (type === 'trust') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const trustedUsers = roomData.trustedUsers ? JSON.parse(roomData.trustedUsers) : [];
    if (trustedUsers.includes(userId)) {
      await interaction.reply({ content: '❌ User sudah ada di trusted list.', ephemeral: true });
      return;
    }

    trustedUsers.push(userId);
    await db.update(partyRooms).set({ trustedUsers: JSON.stringify(trustedUsers) }).where(eq(partyRooms.id, roomData.id));

    if (roomData.isLocked) {
      await channel.permissionOverwrites.edit(userId, { Connect: true });
    }

    await interaction.reply({ content: `✅ ${member.user.username} ditambahkan ke trusted users.`, ephemeral: true });
  } else if (type === 'untrust') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const trustedUsers = roomData.trustedUsers ? JSON.parse(roomData.trustedUsers) : [];
    const index = trustedUsers.indexOf(userId);

    if (index === -1) {
      await interaction.reply({ content: '❌ User tidak ada di trusted list.', ephemeral: true });
      return;
    }

    trustedUsers.splice(index, 1);
    await db.update(partyRooms).set({ trustedUsers: JSON.stringify(trustedUsers) }).where(eq(partyRooms.id, roomData.id));

    if (roomData.isLocked) {
      await channel.permissionOverwrites.delete(userId);
    }

    await interaction.reply({ content: `✅ ${member.user.username} dihapus dari trusted users.`, ephemeral: true });
  } else if (type === 'invite') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const inviter = await interaction.guild.members.fetch(interaction.user.id);
    await member.send(`📩 ${inviter.user.username} mengundang kamu ke voice channel: <#${roomData.channelId}> di server ${interaction.guild.name}!`).catch(() => null);

    await interaction.reply({ content: `✅ Undangan telah dikirim ke ${member.user.username}.`, ephemeral: true });
  } else if (type === 'block') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const blockedUsers = roomData.blockedUsers ? JSON.parse(roomData.blockedUsers) : [];
    if (blockedUsers.includes(userId)) {
      await interaction.reply({ content: '❌ User sudah diblokir.', ephemeral: true });
      return;
    }

    blockedUsers.push(userId);
    await db.update(partyRooms).set({ blockedUsers: JSON.stringify(blockedUsers) }).where(eq(partyRooms.id, roomData.id));

    await channel.permissionOverwrites.edit(userId, { Connect: false });

    if (member.voice.channelId === roomData.channelId) {
      await member.voice.disconnect();
    }

    await interaction.reply({ content: `✅ ${member.user.username} berhasil diblokir.`, ephemeral: true });
  } else if (type === 'unblock') {
    const userId = interaction.fields.getTextInputValue('user_id');
    const member = await interaction.guild.members.fetch(userId).catch(() => null);

    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    const blockedUsers = roomData.blockedUsers ? JSON.parse(roomData.blockedUsers) : [];
    const index = blockedUsers.indexOf(userId);

    if (index === -1) {
      await interaction.reply({ content: '❌ User tidak diblokir.', ephemeral: true });
      return;
    }

    blockedUsers.splice(index, 1);
    await db.update(partyRooms).set({ blockedUsers: JSON.stringify(blockedUsers) }).where(eq(partyRooms.id, roomData.id));

    await channel.permissionOverwrites.delete(userId);

    await interaction.reply({ content: `✅ ${member.user.username} berhasil di-unblock.`, ephemeral: true });
  } else if (type === 'kick') {
    const userId = interaction.fields.getTextInputValue('user_id');

    const member = await interaction.guild.members.fetch(userId).catch(() => null);
    if (!member) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    if (member.voice.channelId !== roomData.channelId) {
      await interaction.reply({ content: '❌ User tidak ada di channel ini.', ephemeral: true });
      return;
    }

    await member.voice.disconnect();
    await interaction.reply({ content: `✅ ${member.user.username} berhasil di-kick dari channel.`, ephemeral: true });
  } else if (type === 'transfer') {
    const newOwnerId = interaction.fields.getTextInputValue('new_owner_id');

    const newOwner = await interaction.guild.members.fetch(newOwnerId).catch(() => null);
    if (!newOwner) {
      await interaction.reply({ content: '❌ User tidak ditemukan.', ephemeral: true });
      return;
    }

    if (newOwner.voice.channelId !== roomData.channelId) {
      await interaction.reply({ content: '❌ User harus ada di channel untuk menjadi owner.', ephemeral: true });
      return;
    }

    const user = await getOrCreateUser(newOwnerId, newOwner.user.username);
    await db.update(partyRooms).set({ ownerId: user.id }).where(eq(partyRooms.id, roomData.id));
    await interaction.reply({ content: `✅ Ownership berhasil ditransfer ke ${newOwner.user.username}`, ephemeral: true });
  } else if (type === 'delete') {
    const confirm = interaction.fields.getTextInputValue('confirm');

    if (confirm !== 'DELETE') {
      await interaction.reply({ content: '❌ Konfirmasi salah. Ketik DELETE untuk menghapus.', ephemeral: true });
      return;
    }

    if (roomData.waitingRoomChannelId) {
      const waitingChannel = await interaction.guild.channels.fetch(roomData.waitingRoomChannelId).catch(() => null);
      if (waitingChannel) await waitingChannel.delete();
    }

    // Thread deletion removed

    await channel.delete();
    await db.delete(partyRooms).where(eq(partyRooms.id, roomData.id));

    await interaction.reply({ content: '✅ Lounge berhasil dihapus.', ephemeral: true });
  }
}

async function handlePartyRoomButton(interaction, params) {
  const action = params[0];
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (action === 'auto') {
    await interaction.deferReply({ ephemeral: true });

    const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

    try {
      let customNames = null;
      try {
        customNames = settings?.privateLoungeNames ? JSON.parse(settings.privateLoungeNames) : null;
      } catch (e) {
        console.error('Failed to parse privateLoungeNames:', e);
      }

      const { category, controlChannel, createChannel } = await createPrivateLounge(interaction, settings, customNames);

      await interaction.editReply({ content: `✅ Private Lounge berhasil di-setup!\n\n📁 Category: <#${category.id}>\n🛠️ Control: <#${controlChannel.id}>\n🔊 Create: <#${createChannel.id}>` });
    } catch (error) {
      console.error('Error setting up lounge:', error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat setup Private Lounge.' });
    }
  } else if (action === 'custom') {
    const modal = new ModalBuilder()
      .setCustomId('partyroom_custom_modal')
      .setTitle('Customize Private Lounge');

    const categoryInput = new TextInputBuilder()
      .setCustomId('category_name')
      .setLabel('Nama Category')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🔊═════ PRIVATE LOUNGE')
      .setValue('🔊═════ PRIVATE LOUNGE');

    const controlInput = new TextInputBuilder()
      .setCustomId('control_name')
      .setLabel('Nama Control Channel')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🛠️┆settings-private')
      .setValue('🛠️┆settings-private');

    const createInput = new TextInputBuilder()
      .setCustomId('create_name')
      .setLabel('Nama Create Channel')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setPlaceholder('🔊┆Create Private')
      .setValue('🔊┆Create Private');

    modal.addComponents(
      new ActionRowBuilder().addComponents(categoryInput),
      new ActionRowBuilder().addComponents(controlInput),
      new ActionRowBuilder().addComponents(createInput)
    );

    await interaction.showModal(modal);
  } else if (action === 'create') {
    const modal = new ModalBuilder()
      .setCustomId('partyroom_create_modal')
      .setTitle('Buat Party Room Baru');

    const nameInput = new TextInputBuilder()
      .setCustomId('room_name')
      .setLabel('Nama Party Room')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(50);

    const limitInput = new TextInputBuilder()
      .setCustomId('user_limit')
      .setLabel('Limit User (Max)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setPlaceholder('10')
      .setValue('10');

    modal.addComponents(
      new ActionRowBuilder().addComponents(nameInput),
      new ActionRowBuilder().addComponents(limitInput)
    );

    await interaction.showModal(modal);
  } else if (action === 'myroom') {
    const [room] = await db.select().from(partyRooms)
      .where(and(
        eq(partyRooms.ownerId, user.id),
        eq(partyRooms.serverId, interaction.guild.id)
      ));

    if (!room) {
      await interaction.reply({ content: '❌ Kamu belum punya party room aktif.', ephemeral: true });
      return;
    }

    const channel = await interaction.guild.channels.fetch(room.channelId);

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle(`🎉 ${room.name}`)
      .addFields(
        { name: 'Status', value: room.isLocked ? '🔒 Locked' : '🔓 Unlocked', inline: true },
        { name: 'User Limit', value: `${room.userLimit} users`, inline: true },
        { name: 'Channel', value: `<#${room.channelId}>`, inline: true }
      );

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`partyroom_toggle_${room.id}`)
          .setLabel(room.isLocked ? '🔓 Unlock' : '🔒 Lock')
          .setStyle(room.isLocked ? ButtonStyle.Success : ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`partyroom_delete_${room.id}`)
          .setLabel('🗑️ Delete')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  } else if (action === 'toggle') {
    const roomId = parseInt(params[1]);
    const [room] = await db.select().from(partyRooms).where(eq(partyRooms.id, roomId));

    if (!room || room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Room tidak ditemukan atau kamu bukan owner.', ephemeral: true });
      return;
    }

    const newLockState = !room.isLocked;
    await db.update(partyRooms).set({ isLocked: newLockState }).where(eq(partyRooms.id, roomId));

    const channel = await interaction.guild.channels.fetch(room.channelId);
    await channel.permissionOverwrites.edit(interaction.guild.id, {
      Connect: !newLockState
    });

    await interaction.reply({ 
      content: `✅ Room berhasil ${newLockState ? 'di-lock 🔒' : 'di-unlock 🔓'}`, 
      ephemeral: true 
    });
  } else if (action === 'delete') {
    const roomId = parseInt(params[1]);
    const [room] = await db.select().from(partyRooms).where(eq(partyRooms.id, roomId));

    if (!room || room.ownerId !== user.id) {
      await interaction.reply({ content: '❌ Room tidak ditemukan atau kamu bukan owner.', ephemeral: true });
      return;
    }

    const channel = await interaction.guild.channels.fetch(room.channelId);
    await channel.delete();
    await db.delete(partyRooms).where(eq(partyRooms.id, roomId));

    await interaction.reply({ content: '✅ Party room berhasil dihapus!', ephemeral: true });
  }
}

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'partyroom_create_modal') {
    const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
    const roomName = interaction.fields.getTextInputValue('room_name');
    const userLimit = parseInt(interaction.fields.getTextInputValue('user_limit')) || 10;

    const channel = await interaction.guild.channels.create({
      name: roomName,
      type: ChannelType.GuildVoice,
      userLimit: userLimit,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.Speak],
        },
      ],
    });

    await db.insert(partyRooms).values({
      ownerId: user.id,
      channelId: channel.id,
      serverId: interaction.guild.id,
      name: roomName,
      userLimit: userLimit,
      isLocked: false,
    });

    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('✅ Party Room Berhasil Dibuat!')
      .addFields(
        { name: 'Nama', value: roomName, inline: true },
        { name: 'Channel', value: `<#${channel.id}>`, inline: true },
        { name: 'User Limit', value: `${userLimit} users`, inline: true }
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  } else if (interaction.customId === 'partyroom_custom_modal') {
    await interaction.deferReply({ ephemeral: true });

    const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

    const categoryName = interaction.fields.getTextInputValue('category_name');
    const controlName = interaction.fields.getTextInputValue('control_name');
    const createName = interaction.fields.getTextInputValue('create_name');

    const customNames = {
      categoryName,
      controlChannel: controlName,
      createChannel: createName
    };

    try {
      const { category, controlChannel, createChannel } = await createPrivateLounge(interaction, settings, customNames);

      await interaction.editReply({ content: `✅ Private Lounge berhasil di-setup!\n\n📁 Category: <#${category.id}>\n🛠️ Control: <#${controlChannel.id}>\n🔊 Create: <#${createChannel.id}>` });
    } catch (error) {
      console.error('Error setting up lounge:', error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat setup Private Lounge.' });
    }
  } else if (interaction.customId === 'gamelounge_custom_modal') {
    await interaction.deferReply({ ephemeral: true });

    const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

    const categoryName = interaction.fields.getTextInputValue('category_name');
    const controlName = interaction.fields.getTextInputValue('control_name');
    const createName = interaction.fields.getTextInputValue('create_name');

    const customNames = {
      categoryName,
      controlChannel: controlName,
      createChannel: createName
    };

    try {
      const { category, controlChannel, createChannel } = await createGameLounge(interaction, settings, customNames);

      await interaction.editReply({ content: `✅ Game Lounge berhasil di-setup!\n\n📁 Category: <#${category.id}>\n🛠️ Control: <#${controlChannel.id}>\n🎮 Create: <#${createChannel.id}>` });
    } catch (error) {
      console.error('Error setting up game lounge:', error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat setup Game Lounge.' });
    }
  } else if (interaction.customId === 'chilllounge_custom_modal') {
    await interaction.deferReply({ ephemeral: true });

    const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

    const categoryName = interaction.fields.getTextInputValue('category_name');
    const controlName = interaction.fields.getTextInputValue('control_name');
    const createName = interaction.fields.getTextInputValue('create_name');

    const customNames = {
      categoryName,
      controlChannel: controlName,
      createChannel: createName
    };

    try {
      const { category, controlChannel, createChannel, musicChannel } = await createChillLounge(interaction, settings, customNames);

      await interaction.editReply({ content: `✅ Chill Lounge berhasil di-setup!\n\n📁 Category: <#${category.id}>\n🛠️ Control: <#${controlChannel.id}>\n🎧 Create: <#${createChannel.id}>\n🎵 Music: <#${musicChannel.id}>` });
    } catch (error) {
      console.error('Error setting up chill lounge:', error);
      await interaction.editReply({ content: '❌ Terjadi kesalahan saat setup Chill Lounge.' });
    }
  }
});

async function handleTwickCommand(interaction) {
  const embed = new EmbedBuilder()
    .setColor('#1DA1F2')
    .setTitle('🐦 Twicking - Social Media Lintas Server')
    .setDescription('Bagikan pemikiran kamu dengan user dari server lain!')
    .addFields(
      { name: '📝 Fitur', value: 'Post, Like, Reply, Repost\nGambar & Video Support' }
    );

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('twick_create')
        .setLabel('✍️ Buat Post')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('twick_feed')
        .setLabel('📰 Feed')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [embed], components: [row] });
}

async function handleTwickButton(interaction, params) {
  const action = params[0];
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (action === 'create') {
    const modal = new ModalBuilder()
      .setCustomId('twick_create_modal')
      .setTitle('Buat Post Baru');

    const contentInput = new TextInputBuilder()
      .setCustomId('content')
      .setLabel('Apa yang kamu pikirkan?')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(2000);

    const imageInput = new TextInputBuilder()
      .setCustomId('image_url')
      .setLabel('URL Gambar (opsional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const videoInput = new TextInputBuilder()
      .setCustomId('video_url')
      .setLabel('URL Video (opsional)')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(contentInput),
      new ActionRowBuilder().addComponents(imageInput),
      new ActionRowBuilder().addComponents(videoInput)
    );

    await interaction.showModal(modal);
  } else if (action === 'feed') {
    const userPosts = await db.select({
      post: twickPosts,
      user: users,
    })
    .from(twickPosts)
    .leftJoin(users, eq(twickPosts.userId, users.id))
    .where(eq(twickPosts.userId, user.id))
    .orderBy(desc(twickPosts.createdAt));

    if (userPosts.length === 0) {
      await interaction.reply({ content: '📭 Kamu belum memiliki post. Buat post pertamamu!', ephemeral: true });
      return;
    }

    const enrichedPosts = await Promise.all(userPosts.map(async (p) => {
      const [likeCount] = await db.select({ count: sql`count(*)` }).from(twickLikes).where(eq(twickLikes.postId, p.post.id));
      const [replyCount] = await db.select({ count: sql`count(*)` }).from(twickReplies).where(eq(twickReplies.postId, p.post.id));
      const [repostCount] = await db.select({ count: sql`count(*)` }).from(twickReposts).where(eq(twickReposts.postId, p.post.id));
      
      return {
        ...p,
        likeCount: likeCount?.count || 0,
        replyCount: replyCount?.count || 0,
        repostCount: repostCount?.count || 0,
      };
    }));

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('twick_select_post')
      .setPlaceholder('Pilih postingan yang ingin dilihat')
      .addOptions(
        enrichedPosts.slice(0, 25).map((p, index) => ({
          label: p.post.content.substring(0, 100),
          description: `❤️ ${p.likeCount} | 💬 ${p.replyCount} | 🔁 ${p.repostCount}`,
          value: `${p.post.id}`,
        }))
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    const embed = new EmbedBuilder()
      .setColor('#1DA1F2')
      .setTitle('📰 Daftar Postingan Kamu')
      .setDescription(`Kamu memiliki ${userPosts.length} postingan. Pilih salah satu untuk melihat detailnya.`)
      .setFooter({ text: `Total ${userPosts.length} postingan` });

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  } else if (action === 'like') {
    const postId = parseInt(params[1]);

    const [existingLike] = await db.select().from(twickLikes)
      .where(and(eq(twickLikes.postId, postId), eq(twickLikes.userId, user.id)));

    if (existingLike) {
      await db.delete(twickLikes).where(eq(twickLikes.id, existingLike.id));
      await interaction.reply({ content: '💔 Like dihapus', ephemeral: true });
    } else {
      await db.insert(twickLikes).values({ postId, userId: user.id });
      await interaction.reply({ content: '❤️ Post di-like!', ephemeral: true });
    }
  } else if (action === 'reply') {
    const postId = parseInt(params[1]);

    const modal = new ModalBuilder()
      .setCustomId(`reply_modal_${postId}`)
      .setTitle('Balas Post');

    const contentInput = new TextInputBuilder()
      .setCustomId('reply_content')
      .setLabel('Balasan kamu')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1000);

    modal.addComponents(new ActionRowBuilder().addComponents(contentInput));
    await interaction.showModal(modal);
  } else if (action === 'repost') {
    const postId = parseInt(params[1]);

    const [existingRepost] = await db.select().from(twickReposts)
      .where(and(eq(twickReposts.postId, postId), eq(twickReposts.userId, user.id)));

    if (existingRepost) {
      await interaction.reply({ content: '❌ Kamu sudah repost ini', ephemeral: true });
      return;
    }

    await db.insert(twickReposts).values({ 
      postId, 
      userId: user.id,
      serverId: interaction.guild.id 
    });

    await interaction.reply({ content: '🔁 Post di-repost!', ephemeral: true });
  } else if (action === 'viewlikes') {
    const postId = parseInt(params[1]);
    
    const likes = await db.select({
      like: twickLikes,
      user: users,
    })
    .from(twickLikes)
    .leftJoin(users, eq(twickLikes.userId, users.id))
    .where(eq(twickLikes.postId, postId));

    if (likes.length === 0) {
      await interaction.reply({ content: '❤️ Belum ada yang like post ini.', ephemeral: true });
      return;
    }

    const userList = likes.map((l, index) => `${index + 1}. ${l.user?.username || 'Unknown User'}`).join('\n');

    const embed = new EmbedBuilder()
      .setColor('#E91E63')
      .setTitle('❤️ Daftar Users yang Like')
      .setDescription(userList)
      .setFooter({ text: `Total: ${likes.length} likes` });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  } else if (action === 'viewreplies') {
    const postId = parseInt(params[1]);
    
    const replies = await db.select({
      reply: twickReplies,
      user: users,
    })
    .from(twickReplies)
    .leftJoin(users, eq(twickReplies.userId, users.id))
    .where(eq(twickReplies.postId, postId))
    .orderBy(desc(twickReplies.createdAt));

    if (replies.length === 0) {
      await interaction.reply({ content: '💬 Belum ada reply untuk post ini.', ephemeral: true });
      return;
    }

    const replyList = replies.slice(0, 10).map((r) => 
      `**${r.user?.username || 'Unknown'}**: ${r.reply.content}`
    ).join('\n\n');

    const embed = new EmbedBuilder()
      .setColor('#3B88C3')
      .setTitle('💬 Daftar Replies')
      .setDescription(replyList)
      .setFooter({ text: `Total: ${replies.length} replies${replies.length > 10 ? ' (menampilkan 10 teratas)' : ''}` });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  } else if (action === 'viewreposts') {
    const postId = parseInt(params[1]);
    
    const reposts = await db.select({
      repost: twickReposts,
      user: users,
    })
    .from(twickReposts)
    .leftJoin(users, eq(twickReposts.userId, users.id))
    .where(eq(twickReposts.postId, postId));

    if (reposts.length === 0) {
      await interaction.reply({ content: '🔁 Belum ada yang repost post ini.', ephemeral: true });
      return;
    }

    const userList = reposts.map((r, index) => `${index + 1}. ${r.user?.username || 'Unknown User'}`).join('\n');

    const embed = new EmbedBuilder()
      .setColor('#17BF63')
      .setTitle('🔁 Daftar Users yang Repost')
      .setDescription(userList)
      .setFooter({ text: `Total: ${reposts.length} reposts` });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
}

async function handleTwickModal(interaction) {
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
  const content = interaction.fields.getTextInputValue('content');
  const imageUrl = interaction.fields.getTextInputValue('image_url') || null;
  const videoUrl = interaction.fields.getTextInputValue('video_url') || null;

  const [post] = await db.insert(twickPosts).values({
    userId: user.id,
    content,
    imageUrl,
    videoUrl,
    serverId: interaction.guild.id,
  }).returning();

  const confirmEmbed = new EmbedBuilder()
    .setColor('#1DA1F2')
    .setTitle('✅ Post Berhasil Dibuat!')
    .setDescription(content)
    .setTimestamp();

  if (imageUrl) confirmEmbed.setImage(imageUrl);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`twick_like_${post.id}`)
        .setLabel('❤️ Like')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`twick_reply_${post.id}`)
        .setLabel('💬 Reply')
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId(`twick_repost_${post.id}`)
        .setLabel('🔁 Repost')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [confirmEmbed], components: [row] });

  const postEmbed = new EmbedBuilder()
    .setColor('#1DA1F2')
    .setAuthor({ 
      name: interaction.user.username, 
      iconURL: interaction.user.displayAvatarURL() 
    })
    .setDescription(content)
    .setTimestamp();

  if (imageUrl) postEmbed.setImage(imageUrl);

  const allSettings = await db.select().from(serverSettings)
    .where(sql`${serverSettings.twickChannelId} IS NOT NULL`);

  for (const settings of allSettings) {
    try {
      const guild = await client.guilds.fetch(settings.serverId);
      const twickChannel = await guild.channels.fetch(settings.twickChannelId);
      await twickChannel.send({ embeds: [postEmbed], components: [row] });
    } catch (error) {
      console.error(`Failed to send post to server ${settings.serverId}:`, error);
    }
  }
}

async function handleReplyModal(interaction) {
  const postId = parseInt(interaction.customId.split('_')[2]);
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
  const content = interaction.fields.getTextInputValue('reply_content');

  await db.insert(twickReplies).values({
    postId,
    userId: user.id,
    content,
  });

  await interaction.reply({ content: '✅ Balasan berhasil dikirim!', ephemeral: true });
}

async function handleTwickPostSelect(interaction) {
  const postId = parseInt(interaction.values[0]);
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  const [postData] = await db.select({
    post: twickPosts,
    user: users,
  })
  .from(twickPosts)
  .leftJoin(users, eq(twickPosts.userId, users.id))
  .where(eq(twickPosts.id, postId));

  if (!postData) {
    await interaction.reply({ content: '❌ Post tidak ditemukan!', ephemeral: true });
    return;
  }

  const [likeCount] = await db.select({ count: sql`count(*)` }).from(twickLikes).where(eq(twickLikes.postId, postId));
  const [replyCount] = await db.select({ count: sql`count(*)` }).from(twickReplies).where(eq(twickReplies.postId, postId));
  const [repostCount] = await db.select({ count: sql`count(*)` }).from(twickReposts).where(eq(twickReposts.postId, postId));

  const embed = new EmbedBuilder()
    .setColor('#1DA1F2')
    .setAuthor({ name: postData.user?.username || 'Unknown User' })
    .setDescription(postData.post.content)
    .addFields(
      { name: '❤️ Likes', value: `${likeCount?.count || 0}`, inline: true },
      { name: '💬 Replies', value: `${replyCount?.count || 0}`, inline: true },
      { name: '🔁 Reposts', value: `${repostCount?.count || 0}`, inline: true }
    )
    .setTimestamp(postData.post.createdAt);

  if (postData.post.imageUrl) embed.setImage(postData.post.imageUrl);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId(`twick_viewlikes_${postId}`)
        .setLabel('❤️ Lihat Likes')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`twick_viewreplies_${postId}`)
        .setLabel('💬 Lihat Replies')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId(`twick_viewreposts_${postId}`)
        .setLabel('🔁 Lihat Reposts')
        .setStyle(ButtonStyle.Primary)
    );

  await interaction.update({ embeds: [embed], components: [row], ephemeral: true });
}

async function handleProfileCommand(interaction) {
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
  const [profile] = await db.select().from(profiles).where(eq(profiles.userId, user.id));

  const embed = new EmbedBuilder()
    .setColor('#9B59B6')
    .setTitle(`👤 Profil ${interaction.user.username}`)
    .addFields(
      { name: '📝 Bio', value: profile.bio || 'Belum ada bio', inline: false },
      { name: '💭 What\'s on your mind', value: profile.whatsOnYourMind || 'Belum diisi', inline: false }
    );

  if (profile.avatarUrl) embed.setThumbnail(profile.avatarUrl);
  if (profile.bannerUrl) embed.setImage(profile.bannerUrl);

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('profile_edit')
        .setLabel('✏️ Edit Profil')
        .setStyle(ButtonStyle.Primary)
    );

  await interaction.reply({ embeds: [embed], components: [row] });
}

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'profile_edit') {
    const modal = new ModalBuilder()
      .setCustomId('profile_edit_modal')
      .setTitle('Edit Profil');

    const bioInput = new TextInputBuilder()
      .setCustomId('bio')
      .setLabel('Bio')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(500);

    const mindInput = new TextInputBuilder()
      .setCustomId('mind')
      .setLabel('What\'s on your mind?')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(200);

    const avatarInput = new TextInputBuilder()
      .setCustomId('avatar')
      .setLabel('URL Foto Profil')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    const bannerInput = new TextInputBuilder()
      .setCustomId('banner')
      .setLabel('URL Banner')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(bioInput),
      new ActionRowBuilder().addComponents(mindInput),
      new ActionRowBuilder().addComponents(avatarInput),
      new ActionRowBuilder().addComponents(bannerInput)
    );

    await interaction.showModal(modal);
  }
});

async function handleProfileModal(interaction) {
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
  const bio = interaction.fields.getTextInputValue('bio') || null;
  const mind = interaction.fields.getTextInputValue('mind') || null;
  const avatar = interaction.fields.getTextInputValue('avatar') || null;
  const banner = interaction.fields.getTextInputValue('banner') || null;

  await db.update(profiles).set({
    bio,
    whatsOnYourMind: mind,
    avatarUrl: avatar,
    bannerUrl: banner,
    updatedAt: new Date(),
  }).where(eq(profiles.userId, user.id));

  await interaction.reply({ content: '✅ Profil berhasil diupdate!', ephemeral: true });
}

async function handleMarketplaceCommand(interaction) {
  const embed = new EmbedBuilder()
    .setColor('#F1C40F')
    .setTitle('🛒 Marketplace Lintas Server')
    .setDescription('Jual beli dengan user dari server lain!')
    .addFields(
      { name: '📦 Fitur', value: 'Listing produk, Like/Dislike, Komentar\nAuto-connect ke DM' }
    );

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('marketplace_create')
        .setLabel('📦 Jual Barang')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId('marketplace_browse')
        .setLabel('🔍 Browse')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('marketplace_search')
        .setLabel('🔎 Cari Barang')
        .setStyle(ButtonStyle.Secondary)
    );

  await interaction.reply({ embeds: [embed], components: [row] });
}

async function handleMarketplaceButton(interaction, params) {
  const action = params[0];
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (action === 'create') {
    const modal = new ModalBuilder()
      .setCustomId('marketplace_create_modal')
      .setTitle('Jual Barang Baru');

    const titleInput = new TextInputBuilder()
      .setCustomId('title')
      .setLabel('Nama Barang')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(100);

    const descInput = new TextInputBuilder()
      .setCustomId('description')
      .setLabel('Deskripsi')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(1000);

    const priceInput = new TextInputBuilder()
      .setCustomId('price')
      .setLabel('Harga')
      .setStyle(TextInputStyle.Short)
      .setRequired(true)
      .setMaxLength(50);

    const imageInput = new TextInputBuilder()
      .setCustomId('image')
      .setLabel('URL Gambar')
      .setStyle(TextInputStyle.Short)
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(titleInput),
      new ActionRowBuilder().addComponents(descInput),
      new ActionRowBuilder().addComponents(priceInput),
      new ActionRowBuilder().addComponents(imageInput)
    );

    await interaction.showModal(modal);
  } else if (action === 'browse') {
    const listings = await db.select({
      listing: marketplaceListings,
      user: users,
      likeCount: sql`count(case when ${marketplaceLikes.isLike} = true then 1 end)`.as('likeCount'),
      dislikeCount: sql`count(case when ${marketplaceLikes.isLike} = false then 1 end)`.as('dislikeCount'),
    })
    .from(marketplaceListings)
    .leftJoin(users, eq(marketplaceListings.userId, users.id))
    .leftJoin(marketplaceLikes, eq(marketplaceListings.id, marketplaceLikes.listingId))
    .groupBy(marketplaceListings.id, users.id)
    .orderBy(desc(marketplaceListings.createdAt))
    .limit(5);

    if (listings.length === 0) {
      await interaction.reply({ content: '📭 Belum ada barang dijual.', ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#F1C40F')
      .setTitle(listings[0].listing.title)
      .setDescription(listings[0].listing.description)
      .addFields(
        { name: '💰 Harga', value: listings[0].listing.price, inline: true },
        { name: '👤 Penjual', value: listings[0].user.username, inline: true },
        { name: '👍', value: `${listings[0].likeCount}`, inline: true },
        { name: '👎', value: `${listings[0].dislikeCount}`, inline: true }
      );

    if (listings[0].listing.imageUrl) embed.setImage(listings[0].listing.imageUrl);

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`marketplace_like_${listings[0].listing.id}`)
          .setLabel('👍 Suka')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`marketplace_dislike_${listings[0].listing.id}`)
          .setLabel('👎 Tidak Suka')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`marketplace_comment_${listings[0].listing.id}`)
          .setLabel('💬 Komentar')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`marketplace_buy_${listings[0].listing.id}`)
          .setLabel('💰 Beli')
          .setStyle(ButtonStyle.Primary)
      );

    await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
  } else if (action === 'like' || action === 'dislike') {
    const listingId = parseInt(params[1]);
    const isLike = action === 'like';

    const [existing] = await db.select().from(marketplaceLikes)
      .where(and(eq(marketplaceLikes.listingId, listingId), eq(marketplaceLikes.userId, user.id)));

    if (existing) {
      await db.update(marketplaceLikes).set({ isLike }).where(eq(marketplaceLikes.id, existing.id));
    } else {
      await db.insert(marketplaceLikes).values({ listingId, userId: user.id, isLike });
    }

    await interaction.reply({ content: `${isLike ? '👍' : '👎'} Berhasil!`, ephemeral: true });
  } else if (action === 'comment') {
    const listingId = parseInt(params[1]);

    const modal = new ModalBuilder()
      .setCustomId(`comment_modal_${listingId}`)
      .setTitle('Tambah Komentar');

    const commentInput = new TextInputBuilder()
      .setCustomId('comment_content')
      .setLabel('Komentar kamu')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(500);

    modal.addComponents(new ActionRowBuilder().addComponents(commentInput));
    await interaction.showModal(modal);
  } else if (action === 'buy') {
    const listingId = parseInt(params[1]);

    const [listing] = await db.select({
      listing: marketplaceListings,
      seller: users,
    })
    .from(marketplaceListings)
    .leftJoin(users, eq(marketplaceListings.userId, users.id))
    .where(eq(marketplaceListings.id, listingId));

    if (!listing) {
      await interaction.reply({ content: '❌ Listing tidak ditemukan.', ephemeral: true });
      return;
    }

    try {
      const seller = await client.users.fetch(listing.seller.discordId);
      const buyer = interaction.user;

      const embedSeller = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('💰 Ada yang Tertarik dengan Barangmu!')
        .setDescription(`**${listing.listing.title}**`)
        .addFields(
          { name: 'Pembeli', value: buyer.username, inline: true },
          { name: 'Harga', value: listing.listing.price, inline: true }
        );

      const embedBuyer = new EmbedBuilder()
        .setColor('#00FF00')
        .setTitle('✅ Permintaan Pembelian Dikirim')
        .setDescription(`Kamu telah menghubungi penjual: **${seller.username}**`)
        .addFields(
          { name: 'Barang', value: listing.listing.title, inline: true },
          { name: 'Harga', value: listing.listing.price, inline: true }
        );

      await seller.send({ embeds: [embedSeller] }).catch(() => {
        console.error(`Failed to send DM to seller ${seller.username}`);
      });

      await buyer.send({ embeds: [embedBuyer] }).catch(() => {
        console.error(`Failed to send DM to buyer ${buyer.username}`);
      });

      await interaction.reply({ content: '✅ Penjual dihubungi via DM!', ephemeral: true });
    } catch (error) {
      console.error('Error in marketplace buy:', error);
      await interaction.reply({ content: '❌ Terjadi kesalahan saat menghubungi penjual. Pastikan penjual masih aktif.', ephemeral: true });
    }
  } else if (action === 'search') {
    const modal = new ModalBuilder()
      .setCustomId('marketplace_search_modal')
      .setTitle('Cari Barang');

    const searchInput = new TextInputBuilder()
      .setCustomId('search_query')
      .setLabel('Cari apa?')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    modal.addComponents(new ActionRowBuilder().addComponents(searchInput));
    await interaction.showModal(modal);
  }
}

async function handleMarketplaceModal(interaction) {
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);

  if (interaction.customId === 'marketplace_create_modal') {
    const title = interaction.fields.getTextInputValue('title');
    const description = interaction.fields.getTextInputValue('description');
    const price = interaction.fields.getTextInputValue('price');
    const imageUrl = interaction.fields.getTextInputValue('image') || null;

    const [listing] = await db.insert(marketplaceListings).values({
      userId: user.id,
      title,
      description,
      price,
      imageUrl,
      serverId: interaction.guild.id,
    }).returning();

    const embed = new EmbedBuilder()
      .setColor('#F1C40F')
      .setTitle('✅ Barang Berhasil Dilisting!')
      .addFields(
        { name: 'Nama', value: title, inline: true },
        { name: 'Harga', value: price, inline: true }
      );

    if (imageUrl) embed.setImage(imageUrl);

    await interaction.reply({ embeds: [embed], ephemeral: true });

    const [settings] = await db.select().from(serverSettings)
      .where(eq(serverSettings.serverId, interaction.guild.id));

    if (settings?.marketplaceChannelId) {
      const marketChannel = await interaction.guild.channels.fetch(settings.marketplaceChannelId);

      const publicEmbed = new EmbedBuilder()
        .setColor('#F1C40F')
        .setTitle(title)
        .setDescription(description)
        .addFields(
          { name: '💰 Harga', value: price, inline: true },
          { name: '👤 Penjual', value: interaction.user.username, inline: true }
        );

      if (imageUrl) publicEmbed.setImage(imageUrl);

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`marketplace_like_${listing.id}`)
            .setLabel('👍 Suka')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId(`marketplace_dislike_${listing.id}`)
            .setLabel('👎 Tidak Suka')
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId(`marketplace_comment_${listing.id}`)
            .setLabel('💬 Komentar')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId(`marketplace_buy_${listing.id}`)
            .setLabel('💰 Beli')
            .setStyle(ButtonStyle.Primary)
        );

      const msg = await marketChannel.send({ embeds: [publicEmbed], components: [row] });
      await db.update(marketplaceListings).set({ messageId: msg.id }).where(eq(marketplaceListings.id, listing.id));
    }
  } else if (interaction.customId === 'marketplace_search_modal') {
    const query = interaction.fields.getTextInputValue('search_query');

    const results = await db.select({
      listing: marketplaceListings,
      user: users,
    })
    .from(marketplaceListings)
    .leftJoin(users, eq(marketplaceListings.userId, users.id))
    .where(sql`${marketplaceListings.title} ILIKE ${`%${query}%`}`)
    .limit(5);

    if (results.length === 0) {
      await interaction.reply({ content: `❌ Tidak ditemukan barang dengan kata kunci: "${query}"`, ephemeral: true });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor('#F1C40F')
      .setTitle(`🔍 Hasil Pencarian: "${query}"`)
      .setDescription(results.map(r => `**${r.listing.title}** - ${r.listing.price}\nPenjual: ${r.user.username}`).join('\n\n'));

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
}

async function handleCommentModal(interaction) {
  const listingId = parseInt(interaction.customId.split('_')[2]);
  const user = await getOrCreateUser(interaction.user.id, interaction.user.username);
  const content = interaction.fields.getTextInputValue('comment_content');

  await db.insert(marketplaceComments).values({
    listingId,
    userId: user.id,
    content,
  });

  const [listing] = await db.select({
    listing: marketplaceListings,
    seller: users,
  })
  .from(marketplaceListings)
  .leftJoin(users, eq(marketplaceListings.userId, users.id))
  .where(eq(marketplaceListings.id, listingId));

  if (listing) {
    const seller = await client.users.fetch(listing.seller.discordId);
    const embed = new EmbedBuilder()
      .setColor('#F1C40F')
      .setTitle('💬 Komentar Baru pada Barangmu')
      .setDescription(`**${listing.listing.title}**`)
      .addFields(
        { name: 'Dari', value: interaction.user.username, inline: true },
        { name: 'Komentar', value: content, inline: false }
      );

    await seller.send({ embeds: [embed] }).catch(() => {});
  }

  await interaction.reply({ content: '✅ Komentar berhasil dikirim!', ephemeral: true });
}

async function handleSetupCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor('#5865F2')
    .setTitle('⚙️ Setup Bot')
    .setDescription('Atur channel untuk fitur Twicking dan Marketplace');

  const menu = new StringSelectMenuBuilder()
    .setCustomId('setup_select')
    .setPlaceholder('Pilih fitur untuk setup')
    .addOptions([
      {
        label: 'Set Channel Twicking',
        description: 'Atur channel untuk feed Twicking',
        value: 'twick',
        emoji: '🐦'
      },
      {
        label: 'Set Channel Marketplace',
        description: 'Atur channel untuk katalog Marketplace',
        value: 'marketplace',
        emoji: '🛒'
      }
    ]);

  const row = new ActionRowBuilder().addComponents(menu);

  await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
}

async function handleSetupSelect(interaction) {
  const feature = interaction.values[0];

  const modal = new ModalBuilder()
    .setCustomId(`setup_${feature}_modal`)
    .setTitle(`Setup ${feature === 'twick' ? 'Twicking' : 'Marketplace'}`);

  const channelInput = new TextInputBuilder()
    .setCustomId('channel_id')
    .setLabel('Channel ID')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setPlaceholder('Masukkan ID channel');

  modal.addComponents(new ActionRowBuilder().addComponents(channelInput));
  await interaction.showModal(modal);
}

async function handleCustomizeLoungeCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const loungeType = interaction.options.getString('lounge_type');
  const loungeNames = { private: 'Private Lounge', game: 'Game Lounge', chill: 'Chill Lounge' };

  const modal = new ModalBuilder()
    .setCustomId(`customlounge_${loungeType}_modal`)
    .setTitle(`Customize ${loungeNames[loungeType]} Names`);

  const categoryInput = new TextInputBuilder()
    .setCustomId('category_name')
    .setLabel('Nama Category')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setPlaceholder(loungeType === 'private' ? 'PRIVATE LOUNGE' : loungeType === 'game' ? 'GAME LOUNGE' : 'CHILL LOUNGE');

  const controlInput = new TextInputBuilder()
    .setCustomId('control_channel')
    .setLabel('Nama Control Channel')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setPlaceholder(loungeType === 'private' ? 'settings-private' : loungeType === 'game' ? 'settings-game' : 'settings-chill');

  const createInput = new TextInputBuilder()
    .setCustomId('create_channel')
    .setLabel('Nama Create Channel')
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setPlaceholder(loungeType === 'private' ? 'Create Private' : loungeType === 'game' ? 'Create Game Room' : 'Create Chill Room');

  modal.addComponents(
    new ActionRowBuilder().addComponents(categoryInput),
    new ActionRowBuilder().addComponents(controlInput),
    new ActionRowBuilder().addComponents(createInput)
  );

  await interaction.showModal(modal);
}

async function handleDuplicateLoungeCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const loungeType = interaction.options.getString('lounge_type');
  const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

  const categoryField = loungeType === 'private' ? 'loungeCategoryId' : loungeType === 'game' ? 'gameCategoryId' : 'chillCategoryId';

  if (!settings?.[categoryField]) {
    await interaction.reply({ 
      content: `❌ ${loungeType === 'private' ? 'Private Lounge' : loungeType === 'game' ? 'Game Lounge' : 'Chill Lounge'} belum di-setup di server ini. Silahkan setup terlebih dahulu.`, 
      ephemeral: true 
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    const loungeNames = { private: 'Private Lounge', game: 'Game Lounge', chill: 'Chill Lounge' };
    const loungeEmoji = { private: '🔊', game: '🎮', chill: '🎧' };

    const namesField = loungeType === 'private' ? 'privateLoungeNames' : loungeType === 'game' ? 'gameLoungeNames' : 'chillLoungeNames';
    let customNames = null;
    try {
      customNames = settings?.[namesField] ? JSON.parse(settings[namesField]) : null;
    } catch (e) {
      console.error(`Failed to parse ${namesField}:`, e);
    }

    const defaultCategoryName = loungeType === 'private' ? '🔊═════ PRIVATE LOUNGE' : loungeType === 'game' ? '🎮═════ GAME LOUNGE' : '🎧═════ CHILL LOUNGE';
    const categoryName = customNames?.categoryName || defaultCategoryName;
    const controlName = customNames?.controlChannel || (loungeType === 'private' ? '🛠️┆settings-private' : loungeType === 'game' ? '🛠️┆settings-game' : '🛠️┆settings-chill');
    const createName = customNames?.createChannel || (loungeType === 'private' ? '🔊┆Create Private' : loungeType === 'game' ? '🎮┆Create Game Room' : '🎧┆Create Chill Room');

    const newCategory = await interaction.guild.channels.create({
      name: `${categoryName} 2`,
      type: ChannelType.GuildCategory,
    });

    const controlChannel = await interaction.guild.channels.create({
      name: controlName,
      type: ChannelType.GuildText,
      parent: newCategory.id,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory],
          deny: [PermissionFlagsBits.SendMessages],
        },
      ],
    });

    let musicChannel = null;
    if (loungeType === 'chill') {
      musicChannel = await interaction.guild.channels.create({
        name: '🎵┆music-commands',
        type: ChannelType.GuildText,
        parent: newCategory.id,
      });
    }

    const createChannel = await interaction.guild.channels.create({
      name: createName,
      type: ChannelType.GuildVoice,
      parent: newCategory.id,
      userLimit: 1,
    });

    const customEmojis = settings?.customEmojis ? JSON.parse(settings.customEmojis) : {};
    const defaultEmojis = ['📝', '⚠️', '🔒', '⏳', '💬', '✅', '❌', '📩', '🥾', '🌐', '🚫', '🔓', '👑', '📤', '🗑️'];
    const emojis = customEmojis[loungeType] ? [...customEmojis[loungeType], ...defaultEmojis.slice(customEmojis[loungeType].length)] : defaultEmojis;

    const embed = new EmbedBuilder()
      .setColor(loungeType === 'private' ? '#5865F2' : loungeType === 'game' ? '#E74C3C' : '#3498DB')
      .setTitle(`${loungeEmoji[loungeType]} ${loungeNames[loungeType]}`)
      .setDescription(`Menu ini digunakan untuk membuat ${loungeNames[loungeType]}${loungeType === 'game' ? ' untuk bermain game bersama' : loungeType === 'chill' ? ' untuk bersantai dan mendengarkan musik' : ''}.\n\n**Cara Menggunakannya:**\nSilahkan masuk ke ${createName} lalu ${loungeType === 'private' ? 'pilih game melalui menu dibawah ini sesuai yang anda inginkan' : 'atur room sesuai kebutuhan'}.${loungeType === 'game' ? '\n\n**Limit Default:** 5 orang (Max 5 orang)' : loungeType === 'chill' ? `\n\n**Channel Music:** Gunakan <#${musicChannel.id}> untuk command music bot.` : '\n\nJika ada masalah dengan Private Lounge, Silahkan hubungi **STAFF** yang tersedia.'}`)
      .setFooter({ text: `${interaction.guild.name} - ${new Date().getFullYear()}deffano_hansen` });

    const row1 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_name`)
          .setLabel(`${emojis[0]} NAME`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_limit`)
          .setLabel(`${emojis[1]} LIMIT`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_privacy`)
          .setLabel(`${emojis[2]} PRIVACY`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_waiting`)
          .setLabel(`${emojis[3]} WAITING R.`)
          .setStyle(ButtonStyle.Secondary)
      );

    const row2 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_trust`)
          .setLabel(`${emojis[5]} TRUST`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_untrust`)
          .setLabel(`${emojis[6]} UNTRUST`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_invite`)
          .setLabel(`${emojis[7]} INVITE`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_kick`)
          .setLabel(`${emojis[8]} KICK`)
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_region`)
          .setLabel(`${emojis[9]} REGION`)
          .setStyle(ButtonStyle.Secondary)
      );

    const row3 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_block`)
          .setLabel(`${emojis[10]} BLOCK`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_unblock`)
          .setLabel(`${emojis[11]} UNBLOCK`)
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_claim`)
          .setLabel(`${emojis[12]} CLAIM`)
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_transfer`)
          .setLabel(`${emojis[13]} TRANSFER`)
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId(`${loungeType}lounge_delete`)
          .setLabel(`${emojis[14]} DELETE`)
          .setStyle(ButtonStyle.Danger)
      );

    await controlChannel.send({ embeds: [embed], components: [row1, row2, row3] });

    await interaction.editReply({ 
      content: `✅ ${loungeNames[loungeType]} berhasil digandakan!\n\n📁 Category: <#${newCategory.id}>\n🛠️ Control: <#${controlChannel.id}>\n${loungeEmoji[loungeType]} Create: <#${createChannel.id}>${musicChannel ? `\n🎵 Music: <#${musicChannel.id}>` : ''}` 
    });
  } catch (error) {
    console.error('Error duplicating lounge:', error);
    await interaction.editReply({ content: '❌ Terjadi kesalahan saat menggandakan lounge.' });
  }
}

async function handleHelpCommand(interaction) {
  const embed = new EmbedBuilder()
    .setColor('#5865F2')
    .setTitle('📚 Panduan Bot Multifungsi')
    .setDescription('Berikut adalah panduan lengkap fitur-fitur bot:')
    .addFields(
      { 
        name: '🔊 Private Lounge', 
        value: '`/partyroom` - Setup sistem Private Lounge (Admin)\n• Join "Create Private" untuk auto-create room\n• Control: Bitrate, Limit, Rename, Region, Kick, Claim, Info, Transfer', 
        inline: false 
      },
      { 
        name: '🎮 Game Lounge', 
        value: '`/gamelounge` - Setup Game Lounge (Admin)\n• Max 5 orang per room\n• Join "Create Game Room" untuk auto-create\n• Fitur kontrol sama dengan Private Lounge', 
        inline: false 
      },
      { 
        name: '🎧 Chill Lounge', 
        value: '`/chilllounge` - Setup Chill Lounge (Admin)\n• Untuk nongkrong santai & musik\n• Channel music command tersedia\n• Limit flexibel: 2, 4, 5, 10, 15, 20', 
        inline: false 
      },
      { 
        name: '🐦 Twicking', 
        value: '`/twick` - Social media lintas server\n• Post text, gambar, video\n• Like, Reply, Repost\n• Feed global dari semua server', 
        inline: false 
      },
      { 
        name: '🛒 Marketplace', 
        value: '`/marketplace` - Jual beli lintas server\n• Listing produk dengan gambar\n• Like/Dislike, Komentar\n• Auto-connect ke penjual via DM', 
        inline: false 
      },
      { 
        name: '👤 Profile', 
        value: '`/profile` - Kelola profil kamu\n• Edit bio, avatar, banner\n• "What\'s on your mind"', 
        inline: false 
      },
      { 
        name: '⚙️ Setup & Kustomisasi', 
        value: '`/setup` - Atur channel bot (Admin)\n`/customizelounge` - Custom nama lounge (Admin)\n`/duplicatelounge` - Gandakan lounge (Admin)\n`/deletelounge` - Hapus lounge (Admin)', 
        inline: false 
      },
      { 
        name: '🎮 Developer Tools', 
        value: '`/customrpc` - Set custom Rich Presence (Developer only)', 
        inline: false 
      }
    )
    .setFooter({ text: `${interaction.guild.name} • Dibuat oleh deffano_hansen`, iconURL: interaction.guild.iconURL() })
    .setTimestamp();

  const row = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setLabel('Support Server')
        .setStyle(ButtonStyle.Link)
        .setURL('https://discord.gg/fHkPJ4r5P')
        .setEmoji('💬'),
      new ButtonBuilder()
        .setLabel('Developer Contact')
        .setStyle(ButtonStyle.Link)
        .setURL('https://www.instagram.com/dev_deffa?igsh=YjRlbmtxaGk0ZWZw')
        .setEmoji('👨‍💻')
    );

  await interaction.reply({ embeds: [embed], components: [row] });
}

async function handleDeleteLoungeCommand(interaction) {
  if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
    await interaction.reply({ content: '❌ Hanya admin yang bisa menggunakan command ini.', ephemeral: true });
    return;
  }

  const loungeType = interaction.options.getString('lounge_type');
  const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, interaction.guild.id));

  const categoryField = loungeType === 'private' ? 'loungeCategoryId' : loungeType === 'game' ? 'gameCategoryId' : 'chillCategoryId';
  const controlField = loungeType === 'private' ? 'loungeControlChannelId' : loungeType === 'game' ? 'gameControlChannelId' : 'chillControlChannelId';
  const createField = loungeType === 'private' ? 'loungeCreateChannelId' : loungeType === 'game' ? 'gameCreateChannelId' : 'chillCreateChannelId';
  const musicField = 'chillMusicChannelId';

  if (!settings?.[categoryField]) {
    await interaction.reply({ 
      content: `❌ ${loungeType === 'private' ? 'Private Lounge' : loungeType === 'game' ? 'Game Lounge' : 'Chill Lounge'} belum di-setup di server ini.`, 
      ephemeral: true 
    });
    return;
  }

  await interaction.deferReply({ ephemeral: true });

  try {
    const category = await interaction.guild.channels.fetch(settings[categoryField]).catch(() => null);

    if (category) {
      const channels = category.children.cache;
      for (const [, channel] of channels) {
        await channel.delete().catch(err => console.error(`Error deleting channel ${channel.name}:`, err));
      }
      await category.delete().catch(err => console.error('Error deleting category:', err));
    }

    await db.delete(partyRooms).where(
      and(
        eq(partyRooms.serverId, interaction.guild.id),
        eq(partyRooms.loungeType, loungeType)
      )
    );

    const updateFields = {
      [categoryField]: null,
      [controlField]: null,
      [createField]: null,
      updatedAt: new Date(),
    };

    if (loungeType === 'chill' && settings[musicField]) {
      updateFields[musicField] = null;
    }

    await db.update(serverSettings)
      .set(updateFields)
      .where(eq(serverSettings.serverId, interaction.guild.id));

    const loungeNames = { private: 'Private Lounge', game: 'Game Lounge', chill: 'Chill Lounge' };
    await interaction.editReply({ 
      content: `✅ ${loungeNames[loungeType]} berhasil dihapus!\n\nSemua channel dan data terkait telah dibersihkan.` 
    });
  } catch (error) {
    console.error('Error deleting lounge:', error);
    await interaction.editReply({ content: '❌ Terjadi kesalahan saat menghapus lounge.' });
  }
}

async function handleCustomRPCCommand(interaction) {
  const DEVELOPER_IDS = ['1336982558180900876']; // Developer Discord IDs

  if (!DEVELOPER_IDS.includes(interaction.user.id)) {
    const embed = new EmbedBuilder()
      .setColor('#E74C3C')
      .setTitle('❌ Akses Ditolak')
      .setDescription('Command ini hanya dapat digunakan oleh developer bot.')
      .setFooter({ text: 'Unauthorized Access' });

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const activityType = interaction.options.getString('type');
  const activityText = interaction.options.getString('text');
  const streamUrl = interaction.options.getString('url');

  try {
    const activityTypes = {
      'PLAYING': 0,
      'STREAMING': 1,
      'LISTENING': 2,
      'WATCHING': 3,
      'COMPETING': 5
    };

    const activity = {
      name: activityText,
      type: activityTypes[activityType]
    };

    if (activityType === 'STREAMING' && streamUrl) {
      activity.url = streamUrl;
    }

    client.user.setPresence({
      activities: [activity],
      status: 'online'
    });

    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('✅ Custom RPC Berhasil Diatur')
      .addFields(
        { name: 'Type', value: activityType, inline: true },
        { name: 'Text', value: activityText, inline: true }
      )
      .setTimestamp();

    if (streamUrl) {
      embed.addFields({ name: 'Stream URL', value: streamUrl, inline: false });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });

    console.log(`🎮 Custom RPC set by ${interaction.user.username}: ${activityType} ${activityText}`);
  } catch (error) {
    console.error('Error setting custom RPC:', error);
    await interaction.reply({ content: '❌ Terjadi kesalahan saat mengatur RPC.', ephemeral: true });
  }
}

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId.startsWith('setup_')) {
    const feature = interaction.customId.split('_')[1];
    const channelId = interaction.fields.getTextInputValue('channel_id');

    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);

    if (!channel) {
      await interaction.reply({ content: '❌ Channel tidak ditemukan!', ephemeral: true });
      return;
    }

    let [settings] = await db.select().from(serverSettings)
      .where(eq(serverSettings.serverId, interaction.guild.id));

    if (!settings) {
      [settings] = await db.insert(serverSettings).values({
        serverId: interaction.guild.id,
        [feature === 'twick' ? 'twickChannelId' : 'marketplaceChannelId']: channelId,
      }).returning();
    } else {
      await db.update(serverSettings)
        .set({ 
          [feature === 'twick' ? 'twickChannelId' : 'marketplaceChannelId']: channelId,
          updatedAt: new Date()
        })
        .where(eq(serverSettings.serverId, interaction.guild.id));
    }

    await interaction.reply({ 
      content: `✅ Channel ${feature === 'twick' ? 'Twicking' : 'Marketplace'} berhasil diatur ke <#${channelId}>`, 
      ephemeral: true 
    });
  } else if (interaction.customId.startsWith('customlounge_')) {
    try {
      const loungeType = interaction.customId.split('_')[1];
      const categoryName = interaction.fields.getTextInputValue('category_name');
      const controlChannelName = interaction.fields.getTextInputValue('control_channel');
      const createChannelName = interaction.fields.getTextInputValue('create_channel');

      let [settings] = await db.select().from(serverSettings)
        .where(eq(serverSettings.serverId, interaction.guild.id));

      const categoryIdMap = {
        private: settings?.loungeCategoryId,
        game: settings?.gameCategoryId,
        chill: settings?.chillCategoryId
      };

      const controlIdMap = {
        private: settings?.loungeControlChannelId,
        game: settings?.gameControlChannelId,
        chill: settings?.chillControlChannelId
      };

      const createIdMap = {
        private: settings?.loungeCreateChannelId,
        game: settings?.gameCreateChannelId,
        chill: settings?.chillCreateChannelId
      };

      const loungeNames = { private: 'Private Lounge', game: 'Game Lounge', chill: 'Chill Lounge' };
      const commandNames = { private: '/partyroom', game: '/gamelounge', chill: '/chilllounge' };

      if (!categoryIdMap[loungeType]) {
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ 
            content: `❌ Maaf Lounge yang anda maksud belum dibuat, silahkan buat lounge terlebih dahulu menggunakan command ${commandNames[loungeType]}`, 
            flags: 64
          });
        }
        return;
      }

      const category = await interaction.guild.channels.fetch(categoryIdMap[loungeType]);
      const controlChannel = await interaction.guild.channels.fetch(controlIdMap[loungeType]);
      const createChannel = await interaction.guild.channels.fetch(createIdMap[loungeType]);

      await category.setName(categoryName);
      await controlChannel.setName(controlChannelName);
      await createChannel.setName(createChannelName);

      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ 
          content: `✅ ${loungeNames[loungeType]} berhasil dikustomisasi!\n\n**Category:** ${categoryName}\n**Control:** ${controlChannelName}\n**Create:** ${createChannelName}`, 
          flags: 64
        });
      }
    } catch (error) {
      console.error('Error handling customlounge modal:', error);
      if (error.code !== 10062 && !interaction.replied && !interaction.deferred) {
        try {
          await interaction.reply({ 
            content: '❌ Terjadi kesalahan saat mengkustomisasi lounge.', 
            flags: 64
          });
        } catch (e) {
          console.error('Failed to send error message:', e);
        }
      }
    }
  }
});

client.on('voiceStateUpdate', async (oldState, newState) => {
  const [settings] = await db.select().from(serverSettings).where(eq(serverSettings.serverId, newState.guild.id));

  if (newState.channelId && settings?.loungeCreateChannelId === newState.channelId) {
    const user = await getOrCreateUser(newState.member.user.id, newState.member.user.username);

    const [existingRoom] = await db.select().from(partyRooms).where(
      and(
        eq(partyRooms.ownerId, user.id),
        eq(partyRooms.serverId, newState.guild.id),
        eq(partyRooms.loungeType, 'private')
      )
    );

    if (existingRoom) {
      const existingChannel = await newState.guild.channels.fetch(existingRoom.channelId).catch(() => null);
      if (existingChannel) {
        await newState.member.voice.setChannel(existingChannel);
        return;
      }
    }

    const newChannel = await newState.guild.channels.create({
      name: newState.member.user.username,
      type: ChannelType.GuildVoice,
      parent: settings.loungeCategoryId,
      bitrate: 64000,
    });

    await db.insert(partyRooms).values({
      ownerId: user.id,
      channelId: newChannel.id,
      serverId: newState.guild.id,
      name: newState.member.user.username,
      isLocked: false,
      bitrate: 64000,
      loungeType: 'private',
    });

    await newState.member.voice.setChannel(newChannel);
    console.log(`✅ Created private lounge for ${newState.member.user.username}`);
  }

  if (newState.channelId && settings?.gameCreateChannelId === newState.channelId) {
    const user = await getOrCreateUser(newState.member.user.id, newState.member.user.username);

    const [existingRoom] = await db.select().from(partyRooms).where(
      and(
        eq(partyRooms.ownerId, user.id),
        eq(partyRooms.serverId, newState.guild.id),
        eq(partyRooms.loungeType, 'game')
      )
    );

    if (existingRoom) {
      const existingChannel = await newState.guild.channels.fetch(existingRoom.channelId).catch(() => null);
      if (existingChannel) {
        await newState.member.voice.setChannel(existingChannel);
        return;
      }
    }

    const newChannel = await newState.guild.channels.create({
      name: `🎮 ${newState.member.user.username}`,
      type: ChannelType.GuildVoice,
      parent: settings.gameCategoryId,
      bitrate: 64000,
      userLimit: 5,
    });

    await db.insert(partyRooms).values({
      ownerId: user.id,
      channelId: newChannel.id,
      serverId: newState.guild.id,
      name: `🎮 ${newState.member.user.username}`,
      isLocked: false,
      bitrate: 64000,
      userLimit: 5,
      loungeType: 'game',
    });

    await newState.member.voice.setChannel(newChannel);
    console.log(`✅ Created game lounge for ${newState.member.user.username}`);
  }

  if (newState.channelId && settings?.chillCreateChannelId === newState.channelId) {
    const user = await getOrCreateUser(newState.member.user.id, newState.member.user.username);

    const [existingRoom] = await db.select().from(partyRooms).where(
      and(
        eq(partyRooms.ownerId, user.id),
        eq(partyRooms.serverId, newState.guild.id),
        eq(partyRooms.loungeType, 'chill')
      )
    );

    if (existingRoom) {
      const existingChannel = await newState.guild.channels.fetch(existingRoom.channelId).catch(() => null);
      if (existingChannel) {
        await newState.member.voice.setChannel(existingChannel);
        return;
      }
    }

    const newChannel = await newState.guild.channels.create({
      name: `🎧 ${newState.member.user.username}`,
      type: ChannelType.GuildVoice,
      parent: settings.chillCategoryId,
      bitrate: 64000,
    });

    await db.insert(partyRooms).values({
      ownerId: user.id,
      channelId: newChannel.id,
      serverId: newState.guild.id,
      name: `🎧 ${newState.member.user.username}`,
      isLocked: false,
      bitrate: 64000,
      loungeType: 'chill',
    });

    await newState.member.voice.setChannel(newChannel);
    console.log(`✅ Created chill lounge for ${newState.member.user.username}`);
  }

  if (oldState.channelId && oldState.channelId !== newState.channelId) {
    const [room] = await db.select().from(partyRooms).where(eq(partyRooms.channelId, oldState.channelId));

    if (room) {
      const channel = oldState.channel;
      if (channel && channel.members.size === 0) {
        console.log(`🗑️ Auto-deleting empty private lounge: ${room.name}`);
        await channel.delete().catch((err) => console.error('Error deleting channel:', err));
        await db.delete(partyRooms).where(eq(partyRooms.id, room.id));
        console.log(`✅ Private lounge "${room.name}" deleted from database`);
      }
    }
  }
});

// Inisialisasi database dan login bot
(async () => {
  try {
    await initDatabase();
    await client.login(process.env.DISCORD_BOT_TOKEN);
  } catch (error) {
    console.error('❌ Error saat memulai bot:', error);
    process.exit(1);
  }
})();