import { pool } from './db.js';

export async function initDatabase() {
  const client = await pool.connect();
  
  try {
    console.log('🔍 Memeriksa database...');

    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        discord_id VARCHAR(255) NOT NULL UNIQUE,
        username VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS profiles (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL UNIQUE,
        bio TEXT,
        whats_on_your_mind TEXT,
        avatar_url TEXT,
        banner_url TEXT,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS twick_posts (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        content TEXT NOT NULL,
        image_url TEXT,
        video_url TEXT,
        server_id VARCHAR(255) NOT NULL,
        message_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS twick_likes (
        id SERIAL PRIMARY KEY,
        post_id INTEGER REFERENCES twick_posts(id) NOT NULL,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS twick_replies (
        id SERIAL PRIMARY KEY,
        post_id INTEGER REFERENCES twick_posts(id) NOT NULL,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS twick_reposts (
        id SERIAL PRIMARY KEY,
        post_id INTEGER REFERENCES twick_posts(id) NOT NULL,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        server_id VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS marketplace_listings (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT NOT NULL,
        price VARCHAR(100) NOT NULL,
        image_url TEXT,
        server_id VARCHAR(255) NOT NULL,
        message_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS marketplace_likes (
        id SERIAL PRIMARY KEY,
        listing_id INTEGER REFERENCES marketplace_listings(id) NOT NULL,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        is_like BOOLEAN NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS marketplace_comments (
        id SERIAL PRIMARY KEY,
        listing_id INTEGER REFERENCES marketplace_listings(id) NOT NULL,
        user_id INTEGER REFERENCES users(id) NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS party_rooms (
        id SERIAL PRIMARY KEY,
        owner_id INTEGER REFERENCES users(id) NOT NULL,
        channel_id VARCHAR(255) NOT NULL UNIQUE,
        server_id VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        is_locked BOOLEAN DEFAULT FALSE NOT NULL,
        user_limit INTEGER,
        bitrate INTEGER DEFAULT 64000,
        region VARCHAR(100),
        lounge_type TEXT DEFAULT 'private',
        trusted_users TEXT,
        blocked_users TEXT,
        waiting_room_channel_id VARCHAR(255),
        thread_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS server_settings (
        id SERIAL PRIMARY KEY,
        server_id VARCHAR(255) NOT NULL UNIQUE,
        twick_channel_id VARCHAR(255),
        marketplace_channel_id VARCHAR(255),
        lounge_category_id VARCHAR(255),
        lounge_control_channel_id VARCHAR(255),
        lounge_create_channel_id VARCHAR(255),
        game_category_id TEXT,
        game_control_channel_id TEXT,
        game_create_channel_id TEXT,
        chill_category_id TEXT,
        chill_control_channel_id TEXT,
        chill_create_channel_id TEXT,
        chill_music_channel_id TEXT,
        custom_emojis TEXT,
        private_lounge_names TEXT,
        game_lounge_names TEXT,
        chill_lounge_names TEXT,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

    // Tambahkan kolom baru jika belum ada (untuk database yang sudah ada sebelumnya)
    await client.query(`
      DO $$ 
      BEGIN 
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='server_settings' AND column_name='private_lounge_names') THEN
          ALTER TABLE server_settings ADD COLUMN private_lounge_names TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='server_settings' AND column_name='game_lounge_names') THEN
          ALTER TABLE server_settings ADD COLUMN game_lounge_names TEXT;
        END IF;
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='server_settings' AND column_name='chill_lounge_names') THEN
          ALTER TABLE server_settings ADD COLUMN chill_lounge_names TEXT;
        END IF;
      END $$;
    `);

    console.log('✅ Database siap! Semua tabel sudah ada.');
    
  } catch (error) {
    console.error('❌ Error setup database:', error.message);
    throw error;
  } finally {
    client.release();
  }
}
