import { REST, Routes, SlashCommandBuilder } from 'discord.js';
import dotenv from 'dotenv';

dotenv.config();

const commands = [
  new SlashCommandBuilder()
    .setName('partyroom')
    .setDescription('Setup Private Lounge system (Admin only)'),

  new SlashCommandBuilder()
    .setName('gamelounge')
    .setDescription('Setup Game Lounge system (Admin only)'),

  new SlashCommandBuilder()
    .setName('chilllounge')
    .setDescription('Setup Chill Lounge system (Admin only)'),

  new SlashCommandBuilder()
    .setName('twick')
    .setDescription('Akses platform twicking'),

  new SlashCommandBuilder()
    .setName('profile')
    .setDescription('Lihat & edit profil'),

  new SlashCommandBuilder()
    .setName('marketplace')
    .setDescription('Akses marketplace'),

  new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Setup channel untuk bot (Admin only)'),

  new SlashCommandBuilder()
    .setName('customizelounge')
    .setDescription('Customize nama-nama lounge (Admin only)')
    .addStringOption(option =>
      option.setName('lounge_type')
        .setDescription('Tipe lounge')
        .setRequired(true)
        .addChoices(
          { name: 'Private Lounge', value: 'private' },
          { name: 'Game Lounge', value: 'game' },
          { name: 'Chill Lounge', value: 'chill' }
        )
    ),

  new SlashCommandBuilder()
    .setName('duplicatelounge')
    .setDescription('Duplicate lounge yang sudah ada (Admin only)')
    .addStringOption(option =>
      option.setName('lounge_type')
        .setDescription('Tipe lounge yang akan diduplicate')
        .setRequired(true)
        .addChoices(
          { name: 'Private Lounge', value: 'private' },
          { name: 'Game Lounge', value: 'game' },
          { name: 'Chill Lounge', value: 'chill' }
        )
    ),

  new SlashCommandBuilder()
    .setName('deletelounge')
    .setDescription('Hapus lounge (Admin only)')
    .addStringOption(option =>
      option.setName('lounge_type')
        .setDescription('Tipe lounge yang akan dihapus')
        .setRequired(true)
        .addChoices(
          { name: 'Private Lounge', value: 'private' },
          { name: 'Game Lounge', value: 'game' },
          { name: 'Chill Lounge', value: 'chill' }
        )
    ),

  new SlashCommandBuilder()
    .setName('help')
    .setDescription('Panduan lengkap fitur bot'),

  new SlashCommandBuilder()
    .setName('customrpc')
    .setDescription('Set custom Rich Presence (Developer only)')
    .addStringOption(option =>
      option.setName('type')
        .setDescription('Tipe activity')
        .setRequired(true)
        .addChoices(
          { name: 'Playing', value: 'PLAYING' },
          { name: 'Streaming', value: 'STREAMING' },
          { name: 'Listening', value: 'LISTENING' },
          { name: 'Watching', value: 'WATCHING' },
          { name: 'Competing', value: 'COMPETING' }
        )
    )
    .addStringOption(option =>
      option.setName('text')
        .setDescription('Text yang akan ditampilkan')
        .setRequired(true)
    )
    .addStringOption(option =>
      option.setName('url')
        .setDescription('URL stream (hanya untuk streaming)')
        .setRequired(false)
    )
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_BOT_TOKEN);

(async () => {
  try {
    console.log('🔄 Mendaftarkan slash commands...');

    await rest.put(
      Routes.applicationCommands(process.env.DISCORD_CLIENT_ID),
      { body: commands },
    );

    console.log('✅ Slash commands berhasil didaftarkan!');
  } catch (error) {
    console.error('❌ Error mendaftarkan commands:', error);
  }
})();